/**
 * Security Utilities
 * Mitigates SSRF (SonarQube S5144)
 */
import { ErrorFactory } from '../exceptions/ZintrustError.js';
/**
 * Validate URL for SSRF protection
 * Ensures URL is either internal or matches allowed domains
 */
const validate = (url, allowedDomains = ['localhost', '127.0.0.1']) => {
    try {
        const parsedUrl = new URL(url);
        const hostname = parsedUrl.hostname;
        // In a real microservices environment, we would check against a service registry
        // For now, we allow localhost and any domain in the allowed list
        const isAllowed = allowedDomains.some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
        if (!isAllowed) {
            throw ErrorFactory.createValidationError(`URL hostname '${hostname}' is not allowed (SSRF Protection)`, { hostname });
        }
    }
    catch (error) {
        const maybeZinError = error;
        if (maybeZinError.code === 'VALIDATION_ERROR') {
            throw error;
        }
        throw ErrorFactory.createValidationError(`Invalid URL: ${url}`, { cause: error });
    }
};
const validateUrl = (url, allowedDomains) => {
    return validate(url, allowedDomains);
};
/**
 * UrlValidator handles URL validation for SSRF protection
 * Sealed namespace for immutability
 */
export const UrlValidator = Object.freeze({
    validate,
    validateUrl,
});
// Re-export for backward compatibility
export { validate, validateUrl };
