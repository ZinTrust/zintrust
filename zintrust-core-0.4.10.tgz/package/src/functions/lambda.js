import { Logger } from '../config/logger.js';
import { LambdaAdapter } from '../runtime/adapters/LambdaAdapter.js';
import { getKernel } from '../runtime/getKernel.js';
export const handler = async (event, context) => {
    try {
        const kernel = await getKernel();
        const adapter = LambdaAdapter.create({
            handler: async (req, res) => {
                await kernel.handle(req, res);
            },
        });
        return await adapter.handle(event, context);
    }
    catch (error) {
        Logger.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: 'Internal Server Error',
            }),
        };
    }
};
