import { Logger } from '../config/logger.js';
import { CloudflareAdapter } from '../runtime/adapters/CloudflareAdapter.js';
import mergeOverrideValues from '../runtime/OverrideValueMerge.js';
import { ProjectRuntime } from '../runtime/ProjectRuntime.js';
import { StartupConfigFile } from '../runtime/StartupConfigFileRegistry.js';
import { WorkerAdapterImports } from '../runtime/WorkerAdapterImports.js';
import { getKernel } from '../runtime/getKernel.js';
const startupConfigModules = Object.freeze([
    {
        file: StartupConfigFile.Broadcast,
        rootModuleId: '@runtime-config/' + 'broadcast.ts',
        serviceModuleId: '@service-runtime-config/' + 'broadcast.ts',
    },
    {
        file: StartupConfigFile.Cache,
        rootModuleId: '@runtime-config/' + 'cache.ts',
        serviceModuleId: '@service-runtime-config/' + 'cache.ts',
    },
    {
        file: StartupConfigFile.Database,
        rootModuleId: '@runtime-config/' + 'database.ts',
        serviceModuleId: '@service-runtime-config/' + 'database.ts',
    },
    {
        file: StartupConfigFile.Mail,
        rootModuleId: '@runtime-config/' + 'mail.ts',
        serviceModuleId: '@service-runtime-config/' + 'mail.ts',
    },
    {
        file: StartupConfigFile.Middleware,
        rootModuleId: '@runtime-config/' + 'middleware.ts',
        serviceModuleId: '@service-runtime-config/' + 'middleware.ts',
    },
    {
        file: StartupConfigFile.Notification,
        rootModuleId: '@runtime-config/' + 'notification.ts',
        serviceModuleId: '@service-runtime-config/' + 'notification.ts',
    },
    {
        file: StartupConfigFile.Queue,
        rootModuleId: '@runtime-config/' + 'queue.ts',
        serviceModuleId: '@service-runtime-config/' + 'queue.ts',
    },
    {
        file: StartupConfigFile.Storage,
        rootModuleId: '@runtime-config/' + 'storage.ts',
        serviceModuleId: '@service-runtime-config/' + 'storage.ts',
    },
]);
const importOptionalDefault = async (moduleId) => {
    try {
        const module = (await import(moduleId));
        return module.default;
    }
    catch {
        return undefined;
    }
};
const resolveStartupOverrideValue = async (entry) => {
    const rootOverride = await importOptionalDefault(entry.rootModuleId);
    const serviceOverride = ProjectRuntime.getActiveService() === undefined
        ? undefined
        : await importOptionalDefault(entry.serviceModuleId);
    if (rootOverride === undefined)
        return serviceOverride;
    if (serviceOverride === undefined)
        return rootOverride;
    return mergeOverrideValues(rootOverride, serviceOverride);
};
const applyStartupConfigOverrides = async () => {
    try {
        const globalAny = globalThis;
        globalAny.__zintrustStartupConfigOverrides ??= new Map();
        const resolvedEntries = await Promise.all(startupConfigModules.map(async (entry) => ({
            file: entry.file,
            value: await resolveStartupOverrideValue(entry),
        })));
        for (const entry of resolvedEntries) {
            if (entry.value === undefined) {
                globalAny.__zintrustStartupConfigOverrides.delete(entry.file);
                continue;
            }
            globalAny.__zintrustStartupConfigOverrides.set(entry.file, entry.value);
        }
    }
    catch (error) {
        Logger.error('Error applying startup config overrides:', error);
        // Best-effort: log and swallow errors since this is an optional.
    }
};
const injectIoredisModule = async () => {
    const globalAny = globalThis;
    if (globalAny.__zintrustIoredisModule !== undefined)
        return;
    try {
        const module = await import('ioredis');
        globalAny.__zintrustIoredisModule = module;
    }
    catch {
        // Best-effort: leave undefined so resolveIORedis can surface a config error.
    }
};
let startupConfigOverridesPromise;
const ensureStartupConfigOverridesLoaded = async () => {
    startupConfigOverridesPromise ??= applyStartupConfigOverrides();
    await startupConfigOverridesPromise;
};
export default {
    async fetch(request, _env, _ctx) {
        try {
            // Make bindings available to framework code in Workers
            globalThis.env = _env;
            const AppRoutes = (await import('@routes/' + 'api.ts'));
            if (AppRoutes !== undefined) {
                globalThis.__zintrustRoutes = AppRoutes;
            }
            await ProjectRuntime.tryLoadWorkerRuntime();
            await ensureStartupConfigOverridesLoaded();
            await WorkerAdapterImports.ready; // NOSONAR - Ensure adapter imports are ready before handling requests.
            await injectIoredisModule();
            const kernel = await getKernel();
            const adapter = CloudflareAdapter.create({
                handler: async (req, res) => {
                    await kernel.handle(req, res);
                },
            });
            const platformResponse = await adapter.handle(request);
            return adapter.formatResponse(platformResponse);
        }
        catch (error) {
            const err = error;
            Logger.error('Cloudflare handler error:', err);
            if (typeof err?.stack === 'string' && err.stack.trim() !== '') {
                Logger.error('Cloudflare handler stack:', err.stack);
            }
            return new Response('Internal Server Error', { status: 500 });
        }
    },
};
