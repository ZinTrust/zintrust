import { Logger } from '../config/logger.js';
import { DenoAdapter } from '../runtime/adapters/DenoAdapter.js';
import { getKernel } from '../runtime/getKernel.js';
const deno = async (request) => {
    try {
        const kernel = await getKernel();
        const adapter = DenoAdapter.create({
            handler: async (req, res) => {
                await kernel.handle(req, res);
            },
        });
        const platformResponse = await adapter.handle(request);
        return adapter.formatResponse(platformResponse);
    }
    catch (error) {
        Logger.error('Deno handler error:', error);
        return new Response('Internal Server Error', { status: 500 });
    }
};
export default deno;
