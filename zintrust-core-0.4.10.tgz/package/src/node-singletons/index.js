/**
 * Node.js Singleton Modules
 * Centralized exports for all node:* imports
 * This allows conditional loading and runtime-aware imports
 *
 * Safe for all runtimes (API, CLI, Serverless):
 * - http
 * - crypto
 * - events
 * - perf-hooks
 *
 * CLI-only (Node.js):
 * - fs
 * - path
 * - child-process
 * - url
 * - os
 * - readline
 */
// Safe for all runtimes
export * from './async_hooks.js';
export * from './crypto.js';
export * from './events.js';
export * from './http.js';
export * from './perf-hooks.js';
export * as process from './process.js';
// CLI-only (should not be imported in API code)
export * as childProcess from './child-process.js';
export * as fs from './fs.js';
export * as module from './module.js';
export * as net from './net.js';
export * as os from './os.js';
export * as path from './path.js';
export * as readline from './readline.js';
export * as tls from './tls.js';
export * as url from './url.js';
