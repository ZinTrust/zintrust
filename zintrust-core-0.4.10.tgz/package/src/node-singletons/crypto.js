/**
 * Node.js Crypto Module Singleton
 * Safe to import in both API and CLI code
 * Exported from node:crypto built-in
 */
export { createCipheriv, createDecipheriv, createHash, createHmac, createSign, createVerify, generateKeyPairSync, pbkdf2, pbkdf2Sync, randomBytes, randomInt, randomUUID, scryptSync, timingSafeEqual, } from 'node:crypto';
