/* eslint-disable no-restricted-imports */
// /**
//  * ZinTrust comon plugin auto-imports
//  *
//  * This file is managed by `zin plugin install` and contains side-effect
//  * imports that register optional adapters/drivers into core registries.
//  */
import '../packages/db-d1/src/register.js';
import '../packages/db-mysql/src/register.js';
import '../packages/db-postgres/src/register.js';
import '../packages/db-sqlite/src/register.js';
import '../packages/db-sqlserver/src/register.js';
import '../packages/mail-sendgrid/src/register.js';
import '../packages/mail-smtp/src/register.js';
import '../packages/queue-redis/src/register.js';
