import serviceManifest from './bootstrap/service-manifest.js';
export { serviceManifest };
export default serviceManifest;
