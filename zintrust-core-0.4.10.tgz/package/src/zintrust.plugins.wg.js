/**
 * Auto-generated fallback module.
 * This file is created by scripts/ensure-worker-plugins.mjs when missing.
 * It allows optional runtime plugin imports to resolve in CI/scaffolded setups.
 */
export const __zintrustGeneratedPluginStub = 'zintrust.plugins.wg.ts';
export default {};
