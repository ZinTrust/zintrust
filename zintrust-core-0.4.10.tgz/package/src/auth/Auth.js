// TEMPLATE_START
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
const { sign, verify } = jwt;
export const Auth = Object.freeze({
    /**
     * Hash a password
     */
    async hash(password) {
        const salt = await bcrypt.genSalt(10);
        return bcrypt.hash(password, salt);
    },
    /**
     * Compare a password with a hash
     */
    async compare(password, hash) {
        return bcrypt.compare(password, hash);
    },
    /**
     * Generate a JWT token
     */
    generateToken(payload, secret, expiresIn = '1h') {
        const options = { expiresIn };
        return sign(payload, secret, options);
    },
    /**
     * Verify a JWT token
     */
    verifyToken(token, secret) {
        return verify(token, secret);
    },
});
// TEMPLATE_END
