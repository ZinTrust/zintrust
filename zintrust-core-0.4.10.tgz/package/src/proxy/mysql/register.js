import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'mysql',
    description: 'MySQL HTTP proxy server',
});
