const registry = new Map();
const register = (proxy) => {
    registry.set(proxy.name, proxy);
};
const get = (name) => registry.get(name);
const list = () => Array.from(registry.values());
export const ProxyRegistry = Object.freeze({
    register,
    get,
    list,
});
