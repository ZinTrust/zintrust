import { isUndefinedOrNull } from '../../helper/index.js';
import { Logger } from '../../config/logger.js';
let cached = null;
const load = async () => {
    if (cached !== null)
        return cached;
    try {
        // Non-literal specifier to avoid tsconfig path alias rewriting in dist builds.
        const pkgName = '@zintrust/cloudflare-d1-proxy';
        cached = (await import(pkgName));
        return cached;
    }
    catch (error) {
        Logger.error(`Optional dependency not installed: @zintrust/cloudflare-d1-proxy. Install it to use ZintrustD1Proxy.`, { error: error instanceof Error ? error.message : String(error) });
    }
    return undefined;
};
// Proxy surface that defers loading until first usage.
export const ZintrustD1Proxy = new Proxy({}, {
    get(_target, prop) {
        if (prop === Symbol.toStringTag)
            return 'ZintrustD1Proxy';
        return async (...args) => {
            const mod = await load();
            if (isUndefinedOrNull(mod) || typeof mod !== 'object')
                return undefined;
            const target = mod.ZintrustD1Proxy ?? mod.default;
            if (!target || typeof target !== 'object') {
                Logger.error(`Invalid module export from @zintrust/cloudflare-d1-proxy: missing ZintrustD1Proxy`);
                return undefined;
            }
            const value = target[prop];
            if (typeof value !== 'function')
                return value;
            return value(...args);
        };
    },
});
export default ZintrustD1Proxy;
