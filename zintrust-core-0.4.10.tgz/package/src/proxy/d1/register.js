import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'd1',
    description: 'Cloudflare D1 Worker proxy endpoint',
});
