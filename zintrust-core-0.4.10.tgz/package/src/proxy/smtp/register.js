import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'smtp',
    description: 'SMTP HTTP proxy server',
});
