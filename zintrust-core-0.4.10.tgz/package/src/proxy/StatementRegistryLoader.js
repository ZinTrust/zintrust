import { Env } from '../config/env.js';
import { isObject } from '../helper/index.js';
import fs from '../node-singletons/fs.js';
const isRecord = (value) => isObject(value);
const parseStatements = (input) => {
    if (!isRecord(input))
        return undefined;
    const out = {};
    for (const [key, value] of Object.entries(input)) {
        if (typeof value === 'string')
            out[key] = value;
    }
    return Object.keys(out).length > 0 ? out : undefined;
};
export const loadStatementRegistry = (prefix) => {
    const file = Env.get(`ZT_${prefix}_STATEMENTS_FILE`, '').trim();
    if (file !== '') {
        try {
            const text = fs.readFileSync(file, 'utf8');
            return parseStatements(JSON.parse(text));
        }
        catch {
            return undefined;
        }
    }
    const json = Env.get(`ZT_${prefix}_STATEMENTS_JSON`, '').trim();
    if (json !== '') {
        try {
            return parseStatements(JSON.parse(json));
        }
        catch {
            return undefined;
        }
    }
    return undefined;
};
