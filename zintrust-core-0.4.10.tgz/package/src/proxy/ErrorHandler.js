const toProxyError = (status, code, message) => ({
    status,
    body: { code, message },
});
export const ErrorHandler = Object.freeze({
    toProxyError,
});
