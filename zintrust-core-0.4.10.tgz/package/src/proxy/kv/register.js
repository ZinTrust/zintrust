import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'kv',
    description: 'Cloudflare KV Worker proxy endpoint',
});
