import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'sqlserver',
    description: 'SQL Server HTTP proxy',
});
