import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'postgres',
    description: 'PostgreSQL HTTP proxy server',
});
