import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'mongodb',
    description: 'MongoDB HTTP proxy',
});
