export const createPoolManager = (create, dispose) => {
    let pool = null;
    const get = () => {
        pool ??= create();
        return pool;
    };
    const disposePool = async () => {
        if (pool === null)
            return;
        const current = pool;
        pool = null;
        await Promise.resolve(dispose(current));
    };
    return Object.freeze({
        get,
        dispose: disposePool,
    });
};
