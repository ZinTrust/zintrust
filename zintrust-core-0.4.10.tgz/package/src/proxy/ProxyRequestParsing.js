import { ErrorHandler } from './ErrorHandler.js';
import { RequestValidator } from './RequestValidator.js';
export const validateProxyRequest = (request) => {
    const methodError = RequestValidator.requirePost(request.method);
    if (methodError) {
        return ErrorHandler.toProxyError(405, methodError.code, methodError.message);
    }
    return null;
};
export const parseJsonBody = (body) => {
    const parsed = RequestValidator.parseJson(body);
    if (!parsed.ok) {
        return ErrorHandler.toProxyError(400, parsed.error.code, parsed.error.message);
    }
    return { ok: true, value: parsed.value };
};
