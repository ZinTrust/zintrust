import { ProxyRegistry } from '../ProxyRegistry.js';
ProxyRegistry.register({
    name: 'redis',
    description: 'Redis HTTP proxy server',
});
