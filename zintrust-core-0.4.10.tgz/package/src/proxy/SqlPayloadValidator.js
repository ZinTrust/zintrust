export const validateSqlPayload = (payload) => {
    const sql = payload['sql'];
    const params = Array.isArray(payload['params']) ? payload['params'] : [];
    if (typeof sql !== 'string') {
        return {
            valid: false,
            error: {
                code: 'VALIDATION_ERROR',
                message: 'sql must be a string',
            },
        };
    }
    return { valid: true, sql, params };
};
