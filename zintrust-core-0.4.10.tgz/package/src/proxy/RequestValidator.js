import { isObject } from '../helper/index.js';
const isRecord = (value) => isObject(value);
const parseJson = (body) => {
    if (body.trim() === '') {
        return { ok: false, error: { code: 'VALIDATION_ERROR', message: 'Body is required' } };
    }
    try {
        const parsed = JSON.parse(body);
        if (!isRecord(parsed)) {
            return { ok: false, error: { code: 'VALIDATION_ERROR', message: 'Body must be an object' } };
        }
        return { ok: true, value: parsed };
    }
    catch (error) {
        return { ok: false, error: { code: 'INVALID_JSON', message: String(error) } };
    }
};
const requirePost = (method) => {
    if (method === 'POST')
        return null;
    return { code: 'METHOD_NOT_ALLOWED', message: 'POST only' };
};
export const RequestValidator = Object.freeze({
    parseJson,
    requirePost,
});
