import { ErrorHandler } from './ErrorHandler.js';
import { validateStatementPayload } from './StatementPayloadValidator.js';
import { isMutatingSql } from './isMutatingSql.js';
export const resolveStatementOrError = (statements, payload) => {
    if (!statements) {
        return {
            ok: false,
            response: ErrorHandler.toProxyError(400, 'CONFIG_ERROR', 'Missing statement registry'),
        };
    }
    const stmtValidation = validateStatementPayload(payload);
    if (!stmtValidation.valid) {
        return {
            ok: false,
            response: ErrorHandler.toProxyError(400, stmtValidation.error.code, stmtValidation.error.message),
        };
    }
    const sql = statements[stmtValidation.statementId];
    if (typeof sql !== 'string' || sql.trim() === '') {
        return {
            ok: false,
            response: ErrorHandler.toProxyError(404, 'NOT_FOUND', 'Unknown statementId'),
        };
    }
    return {
        ok: true,
        value: {
            statementId: stmtValidation.statementId,
            sql,
            params: stmtValidation.params,
            mutating: isMutatingSql(sql),
        },
    };
};
