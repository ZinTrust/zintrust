import { CacheDriverRegistry } from './CacheDriverRegistry.js';
import { KVDriver } from './drivers/KVDriver.js';
import { KVRemoteDriver } from './drivers/KVRemoteDriver.js';
import { MemoryDriver } from './drivers/MemoryDriver.js';
import { MongoDriver } from './drivers/MongoDriver.js';
import { RedisDriver } from './drivers/RedisDriver.js';
/**
 * Register cache drivers from runtime config.
 *
 * This follows the framework's config-driven availability pattern:
 * - Built-in driver factories are registered so config entries can reference them.
 * - Named cache stores are still resolved from `cacheConfig.drivers[storeName]`.
 * - Unknown store names throw when explicitly selected via `cacheConfig.getDriver(name)`.
 */
export function registerCachesFromRuntimeConfig(_config) {
    CacheDriverRegistry.register('memory', () => MemoryDriver.create());
    CacheDriverRegistry.register('redis', () => RedisDriver.create());
    CacheDriverRegistry.register('mongodb', () => MongoDriver.create());
    CacheDriverRegistry.register('kv', () => KVDriver.create());
    CacheDriverRegistry.register('kv-remote', () => KVRemoteDriver.create());
}
