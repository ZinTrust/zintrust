/**
 * Cache Driver Interface
 * Defines contract for different cache implementations
 */
// Runtime marker to make this type-only module coverable in V8 coverage.
export const CACHE_DRIVER_INTERFACE = 'CacheDriver';
