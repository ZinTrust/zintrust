const registry = new Map();
function register(driver, factory) {
    registry.set(driver, factory);
}
function get(driver) {
    return registry.get(driver);
}
function has(driver) {
    return registry.has(driver);
}
function list() {
    return Array.from(registry.keys());
}
export const CacheDriverRegistry = Object.freeze({
    register,
    get,
    has,
    list,
});
