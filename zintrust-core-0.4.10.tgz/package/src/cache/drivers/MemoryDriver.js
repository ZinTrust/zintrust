/**
 * Memory Cache Driver
 * Simple in-memory storage for local development
 */
function isUnrefableTimer(value) {
    return (typeof value === 'object' &&
        value !== null &&
        'unref' in value &&
        typeof value.unref === 'function');
}
/**
 * Memory Cache Driver
 * Simple in-memory storage for local development
 * Refactored to Functional Object pattern
 */
const create = () => {
    const storage = new Map();
    // Background cleanup interval (runs every 60 seconds)
    const cleanupInterval = setInterval(() => {
        const now = Date.now();
        for (const [key, item] of storage.entries()) {
            if (item.expires !== null && item.expires < now) {
                storage.delete(key);
            }
        }
    }, 60_000); // 60 seconds
    // Unref so it doesn't keep process alive (Node.js only)
    if (isUnrefableTimer(cleanupInterval)) {
        cleanupInterval.unref();
    }
    return {
        async get(key) {
            await Promise.resolve();
            const item = storage.get(key);
            if (item === undefined)
                return null;
            if (item.expires !== null && item.expires < Date.now()) {
                storage.delete(key);
                return null;
            }
            return item.value;
        },
        async set(key, value, ttl) {
            const expires = ttl === undefined ? null : Date.now() + ttl * 1000;
            storage.set(key, { value, expires });
            await Promise.resolve();
        },
        async delete(key) {
            storage.delete(key);
            await Promise.resolve();
        },
        async clear() {
            storage.clear();
            await Promise.resolve();
        },
        async has(key) {
            await Promise.resolve();
            const item = storage.get(key);
            if (item === undefined)
                return false;
            if (item.expires !== null && item.expires < Date.now()) {
                storage.delete(key);
                return false;
            }
            return true;
        },
        async dispose() {
            clearInterval(cleanupInterval);
            storage.clear();
            await Promise.resolve();
        },
    };
};
/**
 * MemoryDriver namespace - sealed for immutability
 */
export const MemoryDriver = Object.freeze({
    create,
});
