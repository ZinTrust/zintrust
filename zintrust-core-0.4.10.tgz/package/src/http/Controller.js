/**
 * Base Controller
 * All controllers extend this class
 */
/**
 * Base Controller
 * Sealed namespace for immutability
 */
export const Controller = Object.freeze({
    /**
     * Send JSON response
     */
    json(res, data, statusCode = 200) {
        res.setStatus(statusCode).json(data);
    },
    /**
     * Send error response
     */
    error(res, message, statusCode = 400) {
        res.setStatus(statusCode).json({ error: message });
    },
    /**
     * Redirect response
     */
    redirect(res, url, statusCode = 302) {
        res.redirect(url, statusCode);
    },
    /**
     * Get route parameter
     */
    param(req, name) {
        return req.getParam(name);
    },
    /**
     * Get query parameter
     */
    query(req, name) {
        return req.getQueryParam(name);
    },
    /**
     * Get request body
     */
    body(req) {
        return req.getBody();
    },
});
