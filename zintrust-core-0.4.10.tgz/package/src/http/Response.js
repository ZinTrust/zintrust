/**
 * Response - HTTP Response wrapper
 * Wraps Node.js ServerResponse with additional utilities
 */
import { HTTP_HEADERS, MIME_TYPES } from '../config/constants.js';
/**
 * Response - HTTP Response wrapper
 * Refactored to Functional Object pattern
 */
export const Response = Object.freeze({
    /**
     * Create a new response instance
     */
    create(res) {
        let statusCodeValue = 200;
        const headers = {};
        const locals = {};
        const response = {
            locals,
            status(code) {
                return this.setStatus(code);
            },
            setStatus(code) {
                statusCodeValue = code;
                res.statusCode = code;
                return this;
            },
            getStatus() {
                return statusCodeValue;
            },
            get statusCode() {
                return statusCodeValue;
            },
            setHeader(name, value) {
                headers[name] = value;
                res.setHeader(name, value);
                return this;
            },
            getHeader(name) {
                return headers[name];
            },
            json(data) {
                this.setHeader(HTTP_HEADERS.CONTENT_TYPE, MIME_TYPES.JSON);
                res.end(JSON.stringify(data));
            },
            text(text) {
                this.setHeader(HTTP_HEADERS.CONTENT_TYPE, MIME_TYPES.TEXT);
                res.end(text);
            },
            html(html) {
                this.setHeader(HTTP_HEADERS.CONTENT_TYPE, MIME_TYPES.HTML);
                res.end(html);
            },
            send(data) {
                res.end(data);
            },
            redirect(url, statusCode = 302) {
                this.setStatus(statusCode);
                this.setHeader('Location', url);
                res.end();
            },
            getRaw() {
                return res;
            },
        };
        response.setHeader(HTTP_HEADERS.CONTENT_TYPE, MIME_TYPES.JSON);
        return response;
    },
});
export default Response;
