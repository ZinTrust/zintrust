let provider = null;
function register(next) {
    provider = next;
}
function get() {
    return provider;
}
function has() {
    return provider !== null;
}
function clear() {
    provider = null;
}
export const MultipartParserRegistry = Object.freeze({
    register,
    get,
    has,
    clear,
});
export default MultipartParserRegistry;
