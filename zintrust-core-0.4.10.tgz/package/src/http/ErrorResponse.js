const create = (params) => {
    const hasStack = typeof params.stack === 'string' && params.stack.trim().length > 0;
    return {
        statusCode: params.statusCode,
        message: params.message,
        code: params.code,
        requestId: params.requestId ?? '',
        timestamp: new Date().toISOString(),
        ...(params.details ? { details: params.details } : {}),
        ...(hasStack ? { stack: params.stack } : {}),
    };
};
export const ErrorResponse = Object.freeze({
    create,
    notFound(resource, requestId) {
        return create({
            statusCode: 404,
            message: `${resource} not found`,
            code: 'NOT_FOUND',
            requestId,
        });
    },
    badRequest(message, requestId, details) {
        return create({ statusCode: 400, message, code: 'BAD_REQUEST', requestId, details });
    },
    unauthorized(message, requestId) {
        return create({ statusCode: 401, message, code: 'UNAUTHORIZED', requestId });
    },
    forbidden(message, requestId) {
        return create({ statusCode: 403, message, code: 'FORBIDDEN', requestId });
    },
    conflict(message, requestId) {
        return create({ statusCode: 409, message, code: 'CONFLICT', requestId });
    },
    internalServerError(message = 'Internal server error', requestId, stack) {
        return create({ statusCode: 500, message, code: 'INTERNAL_SERVER_ERROR', requestId, stack });
    },
    serviceUnavailable(message = 'Service unavailable', requestId) {
        return create({ statusCode: 503, message, code: 'SERVICE_UNAVAILABLE', requestId });
    },
});
export default ErrorResponse;
