const getValidated = (req) => {
    return req.validated;
};
export const validatedBody = (req) => {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.body === undefined)
        return undefined;
    return validated.body;
};
export const validatedQuery = (req) => {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.query === undefined)
        return undefined;
    return validated.query;
};
export const validatedParams = (req) => {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.params === undefined)
        return undefined;
    return validated.params;
};
export const validatedHeaders = (req) => {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.headers === undefined)
        return undefined;
    return validated.headers;
};
export const Validated = Object.freeze({
    body: validatedBody,
    query: validatedQuery,
    params: validatedParams,
    headers: validatedHeaders,
});
