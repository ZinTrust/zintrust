/**
 * Validation Helper
 * Utilities for working with validated request data
 */
import { ErrorFactory } from '../exceptions/ZintrustError.js';
const getValidated = (req) => {
    return req.validated;
};
/**
 * Extract validated body from request
 * Returns the validated body if present, undefined otherwise
 *
 * @example
 * ```typescript
 * const body = getValidatedBody(req);
 * if (!body) {
 *   Logger.error('Validation middleware not configured');
 *   return res.setStatus(500).json({ error: 'Internal server error' });
 * }
 * const email = getString(body['email']);
 * ```
 */
export function getValidatedBody(req) {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.body === undefined)
        return undefined;
    return validated.body;
}
/**
 * Check if request has a validated body
 * Type guard for validated body existence
 *
 * @example
 * ```typescript
 * if (!hasValidatedBody(req)) {
 *   Logger.error('Validation middleware not configured');
 *   return res.setStatus(500).json({ error: 'Internal server error' });
 * }
 * const body = getValidatedBody(req)!; // Safe to use non-null assertion
 * ```
 */
export function hasValidatedBody(req) {
    const validated = getValidated(req);
    if (validated === undefined)
        return false;
    if (validated.body === undefined)
        return false;
    return true;
}
/**
 * Extract validated body or throw error
 * Throws if validation middleware is not properly configured
 *
 * @example
 * ```typescript
 * try {
 *   const body = requireValidatedBody(req);
 *   const email = getString(body['email']);
 * } catch (error) {
 *   Logger.error('Validation middleware error', error);
 *   return res.setStatus(500).json({ error: 'Internal server error' });
 * }
 * ```
 */
export function requireValidatedBody(req) {
    const body = getValidatedBody(req);
    if (body === undefined) {
        throw ErrorFactory.createValidationError('Validation middleware did not populate req.validated.body');
    }
    return body;
}
/**
 * Extract validated query parameters from request
 * Returns the validated query if present, undefined otherwise
 */
export function getValidatedQuery(req) {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.query === undefined)
        return undefined;
    return validated.query;
}
/**
 * Extract validated route parameters from request
 * Returns the validated params if present, undefined otherwise
 */
export function getValidatedParams(req) {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.params === undefined)
        return undefined;
    return validated.params;
}
/**
 * Extract validated headers from request
 * Returns the validated headers if present, undefined otherwise
 */
export function getValidatedHeaders(req) {
    const validated = getValidated(req);
    if (validated === undefined)
        return undefined;
    if (validated.headers === undefined)
        return undefined;
    return validated.headers;
}
/**
 * Validation Helper - Sealed namespace
 */
export const ValidationHelper = Object.freeze({
    getValidatedBody,
    hasValidatedBody,
    requireValidatedBody,
    getValidatedQuery,
    getValidatedParams,
    getValidatedHeaders,
});
export default ValidationHelper;
