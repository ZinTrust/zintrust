// CLI utilities (for build tools and scripting)
export { BaseCommand } from './cli/BaseCommand.js';
export { CLI } from './cli/CLI.js';
export { ErrorHandler, EXIT_CODES } from './cli/ErrorHandler.js';
export { WorkerCommands } from './cli/commands/WorkerCommands.js';
export { OptionalCliCommandRegistry } from './cli/OptionalCliCommandRegistry.js';
