import { isArray, isFunction, isNonEmptyString, isObject } from '../helper/index.js';
export const getServiceId = (domain, name) => `${domain}/${name}`;
export const isCanonicalServiceId = (value) => {
    if (!isNonEmptyString(value))
        return false;
    const segments = value.split('/');
    return segments.length === 2 && segments.every((segment) => segment.trim().length > 0);
};
export const toCanonicalServiceId = (args) => {
    if (isCanonicalServiceId(args.id))
        return args.id;
    const domain = isNonEmptyString(args.domain) ? args.domain : 'default';
    const name = isNonEmptyString(args.name) ? args.name : 'unknown';
    return getServiceId(domain, name);
};
export const isServiceManifestEntry = (value) => {
    if (!isObject(value))
        return false;
    if (!isCanonicalServiceId(value['id']))
        return false;
    if (!isNonEmptyString(value['domain']))
        return false;
    if (!isNonEmptyString(value['name']))
        return false;
    const loadRoutes = value['loadRoutes'];
    if (loadRoutes !== undefined && !isFunction(loadRoutes)) {
        return false;
    }
    return true;
};
export const normalizeServiceManifest = (value) => {
    if (!isArray(value))
        return [];
    return value.filter(isServiceManifestEntry).map((entry) => ({
        ...entry,
        id: toCanonicalServiceId(entry),
        monolithEnabled: entry.monolithEnabled !== false,
    }));
};
export const normalizeActiveServiceRuntime = (value) => {
    if (!isObject(value))
        return undefined;
    if (!isNonEmptyString(value['domain']))
        return undefined;
    if (!isNonEmptyString(value['name']))
        return undefined;
    const configRoot = isNonEmptyString(value['configRoot']) ? value['configRoot'] : undefined;
    return Object.freeze({
        id: toCanonicalServiceId(value),
        domain: value['domain'],
        name: value['name'],
        ...(configRoot === undefined ? {} : { configRoot }),
    });
};
export const normalizeProjectRuntimeModule = (value) => {
    if (!isObject(value)) {
        return Object.freeze({});
    }
    return Object.freeze({
        ...(Object.hasOwn(value, 'serviceManifest')
            ? { serviceManifest: normalizeServiceManifest(value['serviceManifest']) }
            : {}),
        ...(Object.hasOwn(value, 'activeService')
            ? { activeService: normalizeActiveServiceRuntime(value['activeService']) }
            : {}),
    });
};
export const serviceMatchesAllowList = (serviceId, serviceName, allowList) => {
    if (allowList.length === 0)
        return true;
    return allowList.includes(serviceId) || allowList.includes(serviceName);
};
export default Object.freeze({
    getServiceId,
    isCanonicalServiceId,
    toCanonicalServiceId,
    isServiceManifestEntry,
    normalizeServiceManifest,
    normalizeActiveServiceRuntime,
    normalizeProjectRuntimeModule,
    serviceMatchesAllowList,
});
