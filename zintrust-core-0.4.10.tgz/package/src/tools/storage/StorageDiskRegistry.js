import { ErrorFactory } from '../../exceptions/ZintrustError.js';
const registry = new Map();
const normalizeKey = (name) => String(name ?? '')
    .trim()
    .toLowerCase();
function register(name, config) {
    const key = normalizeKey(name);
    if (key === '')
        return;
    registry.set(key, config);
}
function has(name) {
    return registry.has(normalizeKey(name));
}
function get(name) {
    const key = normalizeKey(name);
    const cfg = registry.get(key);
    if (cfg === undefined) {
        throw ErrorFactory.createConfigError(`Storage disk not registered: ${name}`);
    }
    return cfg;
}
function list() {
    return Array.from(registry.keys()).sort((a, b) => a.localeCompare(b));
}
function reset() {
    registry.clear();
}
export const StorageDiskRegistry = Object.freeze({
    register,
    has,
    get,
    list,
    reset,
});
export default StorageDiskRegistry;
