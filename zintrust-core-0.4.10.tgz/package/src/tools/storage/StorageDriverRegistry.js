const registry = new Map();
function register(driverName, entry) {
    registry.set(String(driverName).trim().toLowerCase(), entry);
}
function get(driverName) {
    return registry.get(String(driverName).trim().toLowerCase());
}
function has(driverName) {
    return registry.has(String(driverName).trim().toLowerCase());
}
function list() {
    return Array.from(registry.keys()).sort((a, b) => a.localeCompare(b));
}
export const StorageDriverRegistry = Object.freeze({
    register,
    get,
    has,
    list,
});
export default StorageDriverRegistry;
