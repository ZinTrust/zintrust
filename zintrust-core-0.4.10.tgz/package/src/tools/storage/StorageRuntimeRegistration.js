import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { StorageDiskRegistry } from './StorageDiskRegistry.js';
export function registerDisksFromRuntimeConfig(config) {
    for (const [name, driverConfig] of Object.entries(config.drivers)) {
        StorageDiskRegistry.register(name, driverConfig);
    }
    // Alias reserved name `default` to the configured default.
    const defaultName = String(config.default ?? '').trim();
    if (defaultName.length === 0) {
        throw ErrorFactory.createConfigError('Storage default disk is not configured');
    }
    const resolvedDefault = config.drivers[defaultName];
    if (resolvedDefault === undefined) {
        throw ErrorFactory.createConfigError(`Storage default disk not configured: ${defaultName}`);
    }
    StorageDiskRegistry.register('default', resolvedDefault);
}
export const StorageRuntimeRegistration = Object.freeze({
    registerDisksFromRuntimeConfig,
});
export default StorageRuntimeRegistration;
