/**
 * Deduplication Builder - Plain function implementation for BullMQ job deduplication
 * Follows ZinTrust's preference for functions over classes
 */
import { createValidationError } from '../../exceptions/ZintrustError.js';
/**
 * Creates a deduplication builder for configuring job deduplication options
 * @returns {DeduplicationBuilder} Builder instance with fluent interface
 */
export function createDeduplicationBuilder() {
    const state = {};
    return {
        /**
         * Set the unique identifier for deduplication
         * @param id - Unique identifier string
         */
        id(id) {
            state.id = id;
            return this;
        },
        /**
         * Set time-to-live for deduplication lock in milliseconds
         * @param ms - TTL in milliseconds
         */
        expireAfter(ms) {
            state.ttl = ms;
            return this;
        },
        /**
         * Prevent automatic lock release - requires manual release
         */
        dontRelease() {
            state.dontRelease = true;
            return this;
        },
        /**
         * Replace existing job with same ID instead of ignoring
         */
        replace() {
            state.replace = true;
            return this;
        },
        /**
         * Set release strategy for the deduplication lock
         * @param strategy - Release strategy (delay, 'success', or condition object)
         */
        releaseAfter(strategy) {
            state.releaseAfter = strategy;
            return this;
        },
        /**
         * Build the final deduplication options
         * @returns {DeduplicationOptions} Configured deduplication options
         */
        build() {
            if (state.id === null || state.id === undefined) {
                throw createValidationError('Deduplication ID is required. Call .id() before .build()');
            }
            const options = {
                id: state.id,
            };
            if (state.ttl !== undefined) {
                options.ttl = state.ttl;
            }
            if (state.dontRelease === true) {
                options.dontRelease = true;
            }
            if (state.replace === true) {
                options.replace = true;
            }
            if (state.releaseAfter !== undefined) {
                options.releaseAfter = state.releaseAfter;
            }
            return options;
        },
    };
}
