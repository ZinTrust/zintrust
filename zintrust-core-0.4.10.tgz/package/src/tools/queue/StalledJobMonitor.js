import { Logger } from '../../config/logger.js';
import { JobHeartbeatStore } from './JobHeartbeatStore.js';
import { JobStateTracker } from './JobStateTracker.js';
export const StalledJobMonitor = Object.freeze({
    async scanOnce() {
        const expired = await JobHeartbeatStore.listExpired();
        await Promise.all(expired.map(async (row) => {
            await JobStateTracker.stalled({
                queueName: row.queueName,
                jobId: row.jobId,
                reason: 'Heartbeat expired',
            });
            await JobHeartbeatStore.remove(row.queueName, row.jobId);
        }));
        if (expired.length > 0) {
            Logger.warn('Stalled jobs detected from heartbeat store', { count: expired.length });
        }
        return expired.length;
    },
});
export default StalledJobMonitor;
