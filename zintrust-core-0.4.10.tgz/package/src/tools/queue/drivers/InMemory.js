import { generateUuid } from '../../../common/utility.js';
export const InMemoryQueue = (() => {
    const store = new Map();
    const ensure = (queue) => {
        if (!store.has(queue))
            store.set(queue, []);
    };
    return {
        async enqueue(queue, payload) {
            await Promise.resolve();
            ensure(queue);
            const id = generateUuid();
            const msg = {
                id,
                payload: payload,
                attempts: 0,
                enqueuedAt: Date.now(),
            };
            const arr = store.get(queue);
            if (arr && arr.length > 0) {
                arr.push(msg);
            }
            else {
                store.set(queue, [msg]);
            }
            return id;
        },
        async dequeue(queue) {
            await Promise.resolve();
            ensure(queue);
            const arr = store.get(queue);
            if (arr && arr.length > 0) {
                const msg = arr.shift();
                return msg;
            }
            return undefined;
        },
        async ack(_queue, _id) {
            // in-memory dequeue already removed the message; ack is a no-op
            await Promise.resolve();
        },
        async length(queue) {
            await Promise.resolve();
            ensure(queue);
            const arr = store.get(queue);
            return Array.isArray(arr) ? arr.length : 0;
        },
        async drain(queue) {
            await Promise.resolve();
            ensure(queue);
            store.set(queue, []);
        },
    };
})();
export default InMemoryQueue;
