import { ensureDriver } from '../../../config/redis.js';
export const RedisQueue = (() => {
    return {
        __zintrustCoreRedisQueue: true,
        async enqueue(queue, payload) {
            const driver = await ensureDriver();
            return driver.enqueue(queue, payload);
        },
        async dequeue(queue) {
            const driver = await ensureDriver();
            return driver.dequeue(queue);
        },
        async ack(_queue, _id) {
            const driver = await ensureDriver();
            await driver.ack(_queue, _id);
        },
        async length(queue) {
            const driver = await ensureDriver();
            return driver.length(queue);
        },
        async drain(queue) {
            const driver = await ensureDriver();
            await driver.drain(queue);
        },
    };
})();
export default RedisQueue;
