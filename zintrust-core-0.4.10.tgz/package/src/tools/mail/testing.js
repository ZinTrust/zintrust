import { ErrorFactory } from '../../exceptions/ZintrustError.js';
export const MailFake = Object.freeze({
    _sent: [],
    async send(input) {
        const to = Array.isArray(input.to) ? input.to : [input.to];
        this._sent.push({
            to,
            subject: input.subject,
            text: input.text,
            html: input.html,
            from: input.from,
            attachments: input.attachments,
        });
        await Promise.resolve();
        return { ok: true, driver: 'disabled' };
    },
    assertSent(predicate) {
        if (!this._sent.some(predicate)) {
            throw ErrorFactory.createValidationError('Expected a sent mail matching predicate');
        }
    },
    assertNotSent(predicate) {
        if (this._sent.some(predicate)) {
            throw ErrorFactory.createValidationError('Expected no sent mail matching predicate');
        }
    },
    getSent() {
        return this._sent.slice();
    },
    reset() {
        this._sent.length = 0;
    },
});
export default MailFake;
