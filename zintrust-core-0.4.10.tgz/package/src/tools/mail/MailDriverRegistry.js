const registry = new Map();
function register(driver, handler) {
    registry.set(driver, handler);
}
function get(driver) {
    return registry.get(driver);
}
function has(driver) {
    return registry.has(driver);
}
function list() {
    return Array.from(registry.keys());
}
function reset() {
    registry.clear();
}
export const MailDriverRegistry = Object.freeze({
    register,
    get,
    has,
    list,
    reset,
});
