import { ErrorFactory } from '../../../exceptions/ZintrustError.js';
export const BaseDriver = Object.freeze({
    async send() {
        await Promise.resolve();
        throw ErrorFactory.createConfigError('Mail driver must implement send()');
    },
});
export default BaseDriver;
