export default `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Password Reset</title>
    <style>
      body {
        margin: 0;
        padding: 0;
        background-color: #0b1220;
        font-family:
          -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
      }

      .email-container {
        max-width: 600px;
        margin: 40px auto;
        background-color: #0f172a;
        border: 1px solid #334155;
        border-radius: 12px;
        overflow: hidden;
      }

      .header {
        padding: 40px 40px 30px;
        text-align: center;
        background: linear-gradient(180deg, rgba(239, 68, 68, 0.15), rgba(220, 38, 38, 0.08));
        border-bottom: 1px solid #334155;
      }

      .icon {
        width: 48px;
        height: 48px;
        margin: 0 auto 20px;
        border-radius: 12px;
        border: 1px solid rgba(239, 68, 68, 0.35);
        background: linear-gradient(180deg, rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.1));
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .title {
        margin: 0 0 8px;
        font-size: 28px;
        font-weight: 700;
        color: #e2e8f0;
        line-height: 1.2;
      }

      .subtitle {
        margin: 0;
        font-size: 16px;
        color: #e2e8f0;
        line-height: 1.5;
      }

      .content {
        padding: 40px;
      }

      .greeting {
        margin: 0 0 24px;
        font-size: 15px;
        color: #e2e8f0;
        line-height: 1.6;
      }

      .message {
        margin: 0 0 24px;
        font-size: 15px;
        color: #e2e8f0;
        line-height: 1.6;
      }

      .alert-box {
        margin-bottom: 30px;
        padding: 16px;
        background: rgba(239, 68, 68, 0.1);
        border-left: 3px solid #fbbf24;
        border-radius: 6px;
      }

      .alert-box p {
        margin: 0 0 12px;
        font-size: 14px;
        color: #ffffff;
        line-height: 1.6;
      }

      .alert-box strong {
        color: #fbbf24;
      }

      .button-container {
        margin-bottom: 30px;
        text-align: center;
      }

      .reset-button {
        display: inline-block;
        padding: 14px 32px;
        background: linear-gradient(135deg, #ef4444, #dc2626);
        color: #ffffff;
        text-decoration: none;
        border-radius: 8px;
        font-weight: 600;
        font-size: 15px;
        border: 1px solid rgba(239, 68, 68, 0.5);
      }

      .alternative-link {
        margin: 0;
        font-size: 13px;
        color: #f1f5f9;
        line-height: 1.6;
      }

      .alternative-link a {
        color: #bae6fd;
        text-decoration: none;
        word-break: break-all;
      }

      .divider {
        margin: 30px 0;
        border-top: 1px solid #334155;
      }

      .support {
        margin: 0;
        font-size: 14px;
        color: #e2e8f0;
        line-height: 1.6;
      }

      .support a {
        color: #bae6fd;
        text-decoration: none;
      }

      .footer {
        padding: 30px 40px;
        background: rgba(15, 23, 42, 0.65);
        border-top: 1px solid #334155;
        text-align: center;
      }

      .footer p {
        margin: 0;
        font-size: 12px;
        color: #64748b;
      }
    </style>
  </head>
  <body>
    <div class="email-container">
      <!-- Header -->
      <div class="header">
        <div class="icon">
          <span style="font-size: 24px">🔒</span>
        </div>
        <h1 class="title">Password Reset</h1>
        <p class="subtitle">Reset your {{APP_NAME}} account password</p>
      </div>

      <!-- Main Content -->
      <div class="content">
        <p class="greeting">Hi <strong style="color: #e2e8f0">{{name}}</strong>,</p>

        <p class="message">
          Someone requested a password reset for your {{APP_NAME}} account (<strong
            style="color: #e2e8f0"
            >{{email}}</strong
          >). If this was you, click the button below to reset your password:
        </p>

        <div class="alert-box">
          <p>
            <strong>⚠️ Important:</strong> This password reset link will expire in
            <strong>{{expiryTime}}</strong>.
          </p>
        </div>

        <!-- CTA Button -->
        <div class="button-container">
          <a href="{{reset_url}}" class="reset-button">Reset Password</a>
        </div>

        <div class="alternative-link">
          If the button above doesn't work, copy and paste this link into your browser:<br />
          <a href="{{reset_url}}">{{reset_url}}</a>
        </div>

        <!-- Security Notice -->
        <div class="alert-box">
          <p>
            <strong>Security Notice:</strong> If you didn't request this password reset, please
            ignore this email. Your password will remain unchanged.
          </p>
        </div>

        <p class="message">For security reasons, please never share this link with anyone.</p>

        <!-- Divider -->
        <div class="divider"></div>

        <p class="support">
          If you continue to have problems, please contact our
          <a href="{{support_url}}">support team</a>.
        </p>
      </div>

      <!-- Footer -->
      <div class="footer">
        <p>&copy; {{year}} {{APP_NAME}}. All rights reserved.</p>
      </div>
    </div>
  </body>
</html>`;
