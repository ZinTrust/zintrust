import { ErrorFactory } from '../../exceptions/ZintrustError.js';
export async function resolveAttachments(attachments, options = {}) {
    if (!attachments || attachments.length === 0)
        return [];
    const storage = options.storage;
    const resolveOne = async (att) => {
        if ('content' in att) {
            const a = att;
            const content = typeof a.content === 'string' ? Buffer.from(a.content) : a.content;
            return { filename: a.filename, content };
        }
        // Disk-based attachment
        const d = att;
        if (!storage) {
            throw ErrorFactory.createValidationError('Storage is required to resolve disk attachments');
        }
        const exists = storage.exists ? await Promise.resolve(storage.exists(d.disk, d.path)) : true;
        if (!exists) {
            throw ErrorFactory.createNotFoundError(`Attachment not found: ${d.disk}:${d.path}`);
        }
        const content = await Promise.resolve(storage.get(d.disk, d.path));
        const filename = d.filename ?? d.path.split('/').pop() ?? 'attachment';
        return { filename, content };
    };
    return Promise.all(attachments.map(resolveOne));
}
