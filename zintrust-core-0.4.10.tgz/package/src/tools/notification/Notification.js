/**
 * Notification - Public API entry point
 *
 * A small wrapper over NotificationService to provide the expected module name.
 */
import { NotificationService } from './Service.js';
export const Notification = Object.freeze({
    send: NotificationService.send,
    // Alias for send() - explicit intent for immediate notification
    NotifyNow: NotificationService.send,
    // Queue notification for async processing
    async NotifyLater(recipient, message, notifyOptions = {}, queueOptions = {}) {
        const { queueName = 'notifications', timestamp = Date.now() } = queueOptions;
        const { Queue } = await import('../queue/Queue.js');
        const messageId = await Queue.enqueue(queueName, {
            type: 'notification',
            recipient,
            message,
            options: notifyOptions,
            timestamp,
            attempts: 0,
        });
        return messageId ?? '';
    },
    queue(queueName) {
        return Object.freeze({
            NotifyLater: async (recipient, message, notifyOptions = {}, queueOptions = {}) => Notification.NotifyLater(recipient, message, notifyOptions, { ...queueOptions, queueName }),
        });
    },
    channel: (name) => Object.freeze({
        send: async (recipient, message, options) => NotificationService.sendVia(name, recipient, message, options),
    }),
    listDrivers: NotificationService.listDrivers,
});
export default Notification;
