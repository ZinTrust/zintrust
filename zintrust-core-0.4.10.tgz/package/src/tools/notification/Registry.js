import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { ConsoleDriver } from './drivers/Console.js';
import { SlackNotificationDriver } from './drivers/SlackNotification.js';
import { TermiiDriver } from './drivers/Termii.js';
import { TwilioNotificationDriver } from './drivers/TwilioNotification.js';
const drivers = new Map();
drivers.set('termii', TermiiDriver);
drivers.set('console', ConsoleDriver);
drivers.set('slack', SlackNotificationDriver);
drivers.set('twilio', TwilioNotificationDriver);
export const NotificationRegistry = Object.freeze({
    register(name, driver) {
        drivers.set(name.toLowerCase(), driver);
    },
    get(name) {
        const key = (name ?? '').toString().trim().toLowerCase();
        const drv = drivers.get(key);
        if (!drv)
            throw ErrorFactory.createConfigError(`Notification driver not registered: ${name}`);
        return drv;
    },
    list() {
        return Array.from(drivers.keys()).sort((a, b) => a.localeCompare(b));
    },
});
export default NotificationRegistry;
