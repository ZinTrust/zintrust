import { Env } from '../../config/env.js';
export const NotificationConfig = Object.freeze({
    getDriver: () => Env.get('NOTIFICATION_DRIVER', 'console').trim().toLowerCase(),
});
export default NotificationConfig;
