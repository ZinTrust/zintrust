import { Env } from '../../config/env.js';
import { NotificationRegistry } from './Registry.js';
import NotificationFake from './testing.js';
export const useFakeDriver = (name = 'notification-fake', fake = NotificationFake) => {
    let previous;
    try {
        previous = NotificationRegistry.get(name);
    }
    catch {
        previous = undefined;
    }
    const fakeDriver = fake;
    NotificationRegistry.register(name, fakeDriver);
    const prevEnv = Env.get('NOTIFICATION_DRIVER', '');
    Env.set('NOTIFICATION_DRIVER', name);
    return {
        driverName: name,
        restore() {
            // Restore previous driver if present, otherwise keep fake registered
            if (previous === undefined) {
                NotificationRegistry.register(name, NotificationFake);
            }
            else {
                NotificationRegistry.register(name, previous);
            }
            if (prevEnv === '')
                Env.unset('NOTIFICATION_DRIVER');
            else
                Env.set('NOTIFICATION_DRIVER', prevEnv);
        },
    };
};
export default { useFakeDriver };
