import { readdirSync, statSync } from '../../../../node-singletons/fs.js';
import { join, relative } from '../../../../node-singletons/path.js';
import { loadTemplate } from '../../templates/markdown/index.js';
import { MarkdownRenderer } from '../../../templates/index.js';
const BASE = join(process.cwd(), 'src', 'tools', 'notification', 'templates', 'markdown');
const walkDir = (dir, base = dir) => {
    const entries = readdirSync(dir);
    let files = [];
    for (const e of entries) {
        const p = join(dir, e);
        const s = statSync(p);
        if (s.isDirectory()) {
            files = files.concat(walkDir(p, base));
            continue;
        }
        if (e.endsWith('.md')) {
            const rel = relative(base, p).replaceAll('\\', '/');
            const withoutExt = rel.toLowerCase().endsWith('.md') ? rel.slice(0, -3) : rel;
            files.push(withoutExt);
        }
    }
    return files;
};
export const listTemplates = () => {
    return walkDir(BASE);
};
import { ErrorFactory } from '../../../../exceptions/ZintrustError.js';
export const renderTemplate = (name, vars = {}) => {
    const tpl = loadTemplate(name);
    // Basic validation: subject required
    if (tpl.subject === null || tpl.subject === undefined || tpl.subject.trim() === '')
        throw ErrorFactory.createValidationError('Notification template missing subject', { name });
    const html = MarkdownRenderer.render(tpl.content, vars);
    return { html, meta: tpl };
};
export default { listTemplates, renderTemplate };
