import { ErrorFactory } from '../../exceptions/ZintrustError.js';
export const NotificationFake = Object.freeze({
    _sent: [],
    async send(provider, config, payload) {
        this._sent.push({ provider, config, payload });
        await Promise.resolve();
        return { ok: true };
    },
    assertSent(predicate) {
        if (!this._sent.some(predicate))
            throw ErrorFactory.createValidationError('Expected notification to be sent');
    },
    assertNotSent(predicate) {
        if (this._sent.some(predicate))
            throw ErrorFactory.createValidationError('Expected notification to NOT be sent');
    },
    assertSentCount(expected) {
        if (this._sent.length !== expected) {
            throw ErrorFactory.createValidationError('Unexpected notification send count', {
                expected,
                actual: this._sent.length,
            });
        }
    },
    getSent() {
        return [...this._sent];
    },
    lastSent() {
        return this._sent.length > 0 ? this._sent.at(-1) : undefined;
    },
    reset() {
        this._sent.length = 0;
    },
});
export default NotificationFake;
