import notificationConfig from '../../../config/notification.js';
import { SlackDriver } from '../drivers/Slack.js';
export const SlackNotificationDriver = Object.freeze({
    async send(_recipient, message, options = {}) {
        const cfg = notificationConfig.providers.slack;
        const payload = {
            text: message,
            ...options,
        };
        return SlackDriver.send({ webhookUrl: cfg.webhookUrl }, payload);
    },
});
export default SlackNotificationDriver;
