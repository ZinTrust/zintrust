import notificationConfig from '../../../config/notification.js';
import { TwilioDriver } from '../drivers/Twilio.js';
export const TwilioNotificationDriver = Object.freeze({
    async send(recipient, message) {
        const cfg = notificationConfig.providers.twilio;
        return TwilioDriver.send({
            accountSid: cfg.accountSid,
            authToken: cfg.authToken,
            from: cfg.fromNumber,
        }, { to: recipient, body: message });
    },
});
export default TwilioNotificationDriver;
