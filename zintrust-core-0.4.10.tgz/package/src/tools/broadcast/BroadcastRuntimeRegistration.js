import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { BroadcastRegistry } from './BroadcastRegistry.js';
/**
 * Register broadcasters from runtime config.
 *
 * This follows the framework's config-driven availability pattern:
 * - Every `broadcastConfig.drivers[name]` is registered under `name`.
 * - The configured default name is also registered as `'default'`.
 * - Unknown names throw when selected via `BroadcastRegistry.get(name)`.
 */
export function registerBroadcastersFromRuntimeConfig(config) {
    for (const [name, driverConfig] of Object.entries(config.drivers)) {
        BroadcastRegistry.register(name, driverConfig);
    }
    const defaultName = (config.default ?? '').toString().trim().toLowerCase();
    if (defaultName.length === 0) {
        throw ErrorFactory.createConfigError('Broadcast default driver is not configured');
    }
    if (!BroadcastRegistry.has(defaultName)) {
        throw ErrorFactory.createConfigError(`Broadcast default driver not configured: ${defaultName}`);
    }
    BroadcastRegistry.register('default', BroadcastRegistry.get(defaultName));
}
