import { ErrorFactory } from '../../exceptions/ZintrustError.js';
const registry = new Map();
const normalize = (value) => value.trim().toLowerCase();
function register(name, config) {
    registry.set(normalize(name), config);
}
function get(name) {
    const key = normalize(name);
    const found = registry.get(key);
    if (found !== undefined)
        return found;
    throw ErrorFactory.createConfigError(`Broadcast driver not configured: ${key}`);
}
function has(name) {
    return registry.has(normalize(name));
}
function list() {
    return Array.from(registry.keys());
}
function reset() {
    registry.clear();
}
export const BroadcastRegistry = Object.freeze({
    register,
    get,
    has,
    list,
    reset,
});
