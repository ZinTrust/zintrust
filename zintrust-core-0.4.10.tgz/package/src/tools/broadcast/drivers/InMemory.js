export const InMemoryDriver = Object.freeze({
    _events: [],
    async send(_config, channel, event, data) {
        // ensure function is async and returns a resolved promise
        await Promise.resolve();
        this._events.push({ channel, event, data });
        return { ok: true };
    },
    getEvents() {
        return this._events.slice();
    },
    reset() {
        this._events.length = 0;
    },
});
export default InMemoryDriver;
