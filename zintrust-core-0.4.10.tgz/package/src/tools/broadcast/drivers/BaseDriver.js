import { ErrorFactory } from '../../../exceptions/ZintrustError.js';
export const BaseDriver = Object.freeze({
    async send() {
        await Promise.resolve();
        throw ErrorFactory.createConfigError('Broadcast driver must implement send()');
    },
});
export default BaseDriver;
