import { ensureDriver } from '../../../config/redis.js';
import { ErrorFactory } from '../../../exceptions/ZintrustError.js';
import { createRedisKey } from '../../redis/RedisKeyManager.js';
const normalizePrefix = (value) => {
    const prefix = (value ?? '').trim();
    return prefix || 'broadcast:';
};
export const RedisDriver = (() => {
    return {
        async send(config, channel, event, data) {
            const cli = await ensureDriver('publish');
            const prefixedChannel = createRedisKey(`broadcast:${normalizePrefix(config.channelPrefix)}${channel}`);
            let message;
            try {
                message = JSON.stringify({ event, data });
            }
            catch (err) {
                throw ErrorFactory.createTryCatchError('Failed to serialize broadcast payload', err);
            }
            const published = await cli.publish(prefixedChannel, message);
            return { ok: true, published };
        },
    };
})();
export default RedisDriver;
