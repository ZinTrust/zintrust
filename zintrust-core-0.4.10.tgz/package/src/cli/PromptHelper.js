/**
 * Prompt Helper - Interactive CLI Prompts
 * Provides reusable prompt utilities using inquirer
 */
import inquirer from 'inquirer';
/**
 * Prompt Helper Factory
 * Sealed namespace for immutability
 */
export const PromptHelper = Object.freeze({
    /**
     * Generic prompt method for custom questions
     */
    async prompt(questions) {
        return inquirer.prompt(questions);
    },
    /**
     * Ask for project name
     */
    async projectName(defaultName, interactive = true) {
        if (!interactive && defaultName !== undefined && defaultName !== '') {
            return defaultName;
        }
        const answer = await inquirer.prompt([
            {
                type: 'input',
                name: 'projectName',
                message: 'Project name:',
                default: defaultName ?? 'my-zintrust-app',
                validate: (input) => {
                    if (!input.trim())
                        return 'Project name cannot be empty';
                    if (!/^[a-z\d\-_]+$/i.test(input))
                        return 'Project name can only contain letters, numbers, hyphens, and underscores';
                    return true;
                },
            },
        ]);
        return answer.projectName;
    },
    /**
     * Ask for database type
     */
    async databaseType(defaultDb = 'postgresql', interactive = true) {
        if (!interactive) {
            return defaultDb;
        }
        const answer = await inquirer.prompt([
            {
                type: 'list',
                name: 'database',
                message: 'Select database:',
                choices: [
                    { name: 'PostgreSQL — Production-ready relational DB', value: 'postgresql' },
                    { name: 'MySQL — Production-ready relational DB', value: 'mysql' },
                    { name: 'SQLite — Local dev (file-based)', value: 'sqlite' },
                    { name: 'd1-proxy — Cloudflare D1 via HTTPS proxy', value: 'd1-remote' },
                ],
                default: defaultDb,
            },
        ]);
        return answer['database'];
    },
    /**
     * Ask for port number
     */
    async port(defaultPort = 7777, interactive = true) {
        if (!interactive) {
            return defaultPort;
        }
        const answer = await inquirer.prompt([
            {
                type: 'number',
                name: 'port',
                message: 'Server port:',
                default: defaultPort,
                validate: (input) => {
                    if (input < 1 || input > 65535)
                        return 'Port must be between 1 and 65535';
                    return true;
                },
            },
        ]);
        return answer.port;
    },
    /**
     * Ask for feature selection
     */
    async selectFeatures(availableFeatures = ['auth', 'payments', 'notifications'], interactive = true) {
        if (!interactive) {
            return availableFeatures.slice(0, 1);
        }
        const answer = await inquirer.prompt([
            {
                type: 'checkbox',
                name: 'features',
                message: 'Select features to include:',
                choices: availableFeatures,
                default: [],
            },
        ]);
        return answer.features;
    },
    /**
     * Confirm action
     */
    async confirm(message, defaultConfirm = true, interactive = true) {
        if (!interactive) {
            return defaultConfirm;
        }
        const answer = await inquirer.prompt([
            {
                type: 'confirm',
                name: 'confirmed',
                message,
                default: defaultConfirm,
            },
        ]);
        return answer.confirmed;
    },
    /**
     * Choose from list
     */
    async chooseFrom(message, choices, defaultChoice = choices[0], interactive = true) {
        if (!interactive) {
            return defaultChoice;
        }
        const answer = await inquirer.prompt([
            {
                type: 'list',
                name: 'choice',
                message,
                choices,
                default: defaultChoice,
            },
        ]);
        return answer['choice'];
    },
    /**
     * Get text input
     */
    async textInput(message, defaultValue = '', interactive = true) {
        if (!interactive) {
            return defaultValue;
        }
        const answer = await inquirer.prompt([
            {
                type: 'input',
                name: 'input',
                message,
                default: defaultValue,
            },
        ]);
        return answer.input;
    },
});
