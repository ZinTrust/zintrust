import { getRuntimeMode } from '../../runtime/detectRuntime.js';
import { BaseCommand } from '../BaseCommand.js';
import { Env } from '../../config/env.js';
import { Logger } from '../../config/logger.js';
export const DoctorArchitectureCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'doctor:architecture',
            aliases: ['d'],
            description: 'Validate producer/consumer architecture configuration',
            async execute() {
                Logger.info('🩺 Diagnosing Architecture Configuration...');
                const mode = getRuntimeMode();
                const workerEnabled = Env.getBool('WORKER_ENABLED', true);
                const dockerWorker = Env.getBool('DOCKER_WORKER', false);
                Logger.info('----------------------------------------');
                Logger.info(`Runtime Mode:    ${mode}`);
                Logger.info(`Docker Worker:   ${dockerWorker}`);
                Logger.info(`Worker Enabled:  ${workerEnabled}`);
                Logger.info('----------------------------------------');
                const issues = [];
                // Rule 1: Cloudflare Workers cannot run Consumers
                if (mode === 'cloudflare-workers' && workerEnabled) {
                    issues.push('❌ CRITICAL: Cloudflare Workers runtime detected but WORKER_ENABLED=true. Consumers will fail due to connection persistence limits. Set WORKER_ENABLED=false.');
                }
                // Rule 2: Containers should generally run Workers (unless dedicated to API)
                if (mode === 'containers' && !workerEnabled) {
                    issues.push('⚠️ WARNING: Container runtime detected but WORKER_ENABLED=false. Are these containers for API only? If attempting to process jobs, enable workers.');
                }
                // Rule 2b: Dedicated Docker worker containers must keep workers enabled
                if (mode === 'containers' && dockerWorker && !workerEnabled) {
                    issues.push('❌ CRITICAL: DOCKER_WORKER=true but WORKER_ENABLED=false. Dedicated worker containers must enable workers or unset DOCKER_WORKER.');
                }
                // Rule 3: Proxy requirement for Cloudflare
                if (mode === 'cloudflare-workers') {
                    const useProxy = Env.getBool('USE_REDIS_PROXY', false) ||
                        Env.getBool('ENABLE_CLOUDFLARE_SOCKETS', false);
                    if (!useProxy) {
                        issues.push('❌ CRITICAL: Cloudflare runtime requires USE_REDIS_PROXY=true or ENABLE_CLOUDFLARE_SOCKETS=true for Queue producers.');
                    }
                }
                if (issues.length > 0) {
                    Logger.error('Found configuration issues:');
                    issues.forEach((issue) => Logger.error(issue));
                    process.exit(1);
                }
                else {
                    Logger.info('✅ Architecture configuration looks valid for this runtime.');
                }
                await Promise.resolve();
            },
        });
    },
});
