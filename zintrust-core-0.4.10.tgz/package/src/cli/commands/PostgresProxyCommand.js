import { BaseCommand } from '../BaseCommand.js';
import { addSqlProxyOptions, runSqlProxyCommand, } from '../commands/SqlProxyCommandUtils.js';
import { Env } from '../../config/env.js';
import { PostgresProxyServer } from '../../proxy/postgres/PostgresProxyServer.js';
const addOptions = (command) => {
    addSqlProxyOptions(command, {
        hostDefault: Env.POSTGRES_PROXY_HOST,
        portDefault: Env.POSTGRES_PROXY_PORT,
        maxBodyBytesDefault: Env.POSTGRES_PROXY_MAX_BODY_BYTES,
        dbVendorLabel: 'PostgreSQL',
        requireSigningDefault: Env.POSTGRES_PROXY_REQUIRE_SIGNING,
        keyIdDefault: Env.POSTGRES_PROXY_KEY_ID,
        secretDefault: Env.POSTGRES_PROXY_SECRET,
        signingWindowMsDefault: Env.POSTGRES_PROXY_SIGNING_WINDOW_MS,
    });
};
export const PostgresProxyCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'proxy:postgres',
            aliases: ['postgres:proxy', 'postgres-proxy', 'proxy:pg', 'pg:proxy', 'pg-proxy'],
            description: 'Start the PostgreSQL HTTP proxy for Cloudflare Workers',
            addOptions,
            execute: async (options) => {
                await runSqlProxyCommand(options, async (input) => {
                    await PostgresProxyServer.start(input);
                });
            },
        });
    },
});
export default PostgresProxyCommand;
