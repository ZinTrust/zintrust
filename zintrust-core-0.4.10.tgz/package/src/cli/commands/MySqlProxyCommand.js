import { BaseCommand } from '../BaseCommand.js';
import { addSqlProxyOptions, runSqlProxyCommand, } from '../commands/SqlProxyCommandUtils.js';
import { Env } from '../../config/env.js';
import { MySqlProxyServer } from '../../proxy/mysql/MySqlProxyServer.js';
const addOptions = (command) => {
    addSqlProxyOptions(command, {
        hostDefault: Env.MYSQL_PROXY_HOST,
        portDefault: Env.MYSQL_PROXY_PORT,
        maxBodyBytesDefault: Env.MYSQL_PROXY_MAX_BODY_BYTES,
        dbVendorLabel: 'MySQL',
        requireSigningDefault: Env.MYSQL_PROXY_REQUIRE_SIGNING,
        keyIdDefault: Env.MYSQL_PROXY_KEY_ID,
        secretDefault: Env.MYSQL_PROXY_SECRET,
        signingWindowMsDefault: Env.MYSQL_PROXY_SIGNING_WINDOW_MS,
    });
};
export const MySqlProxyCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'proxy:mysql',
            aliases: ['mysql:proxy', 'mysql-proxy', 'proxy:my'],
            description: 'Start the MySQL HTTP proxy for Cloudflare Workers',
            addOptions,
            execute: async (options) => {
                await runSqlProxyCommand(options, async (input) => {
                    await MySqlProxyServer.start(input);
                });
            },
        });
    },
});
export default MySqlProxyCommand;
