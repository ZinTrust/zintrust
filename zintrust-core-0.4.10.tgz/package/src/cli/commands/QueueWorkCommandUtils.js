import { Logger } from '../../config/logger.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
export const QueueWorkCommandUtils = Object.freeze({
    parsePositiveInt: (value, flag) => {
        if (value === undefined)
            return undefined;
        const raw = String(value).trim();
        if (raw === '')
            return undefined;
        const n = Number.parseInt(raw, 10);
        if (!Number.isFinite(n) || n <= 0) {
            throw ErrorFactory.createCliError(`Error: Invalid ${flag} '${raw}'. Expected a positive integer.`);
        }
        return n;
    },
    parseNonNegativeInt: (value, flag) => {
        if (value === undefined)
            return undefined;
        const raw = String(value).trim();
        if (raw === '')
            return undefined;
        const n = Number.parseInt(raw, 10);
        if (!Number.isFinite(n) || n < 0) {
            throw ErrorFactory.createCliError(`Error: Invalid ${flag} '${raw}'. Expected a non-negative integer.`);
        }
        return n;
    },
    normalizeDriverName: (value) => {
        const raw = typeof value === 'string' ? value.trim() : '';
        return raw === '' ? undefined : raw;
    },
    requireQueueNameFromArgs: (args, helpHint) => {
        const queueName = typeof args?.[0] === 'string' ? String(args[0]) : '';
        if (queueName.trim() === '') {
            throw ErrorFactory.createCliError(`Error: Missing <queueName>. Try '${helpHint}'.`);
        }
        return queueName;
    },
    logSummary: (queueName, kindLabel, result) => {
        Logger.info(`Queue work complete (${kindLabel}) for '${queueName}': processed=${result.processed} retried=${result.retried} dropped=${result.dropped} notDueRequeued=${result.notDueRequeued} unknown=${result.unknown}`);
    },
});
export default QueueWorkCommandUtils;
