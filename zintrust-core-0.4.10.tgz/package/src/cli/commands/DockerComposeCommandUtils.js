import { SpawnUtil } from '../utils/spawn.js';
import { Logger } from '../../config/logger.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { existsSync } from '../../node-singletons/fs.js';
import { join } from '../../node-singletons/path.js';
export const resolveComposePath = (composeFileName, missingMessage) => {
    const composePath = join(process.cwd(), composeFileName);
    if (!existsSync(composePath)) {
        throw ErrorFactory.createCliError(missingMessage);
    }
    return composePath;
};
export const runComposeWithFallback = async (args) => {
    try {
        const exitCode = await SpawnUtil.spawnAndWait({ command: 'docker', args });
        if (exitCode !== 0)
            process.exit(exitCode);
        return;
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        if (!message.includes("'docker' not found")) {
            throw error;
        }
    }
    Logger.warn("'docker' not found. Falling back to 'docker-compose'.");
    const exitCode = await SpawnUtil.spawnAndWait({
        command: 'docker-compose',
        args: args.slice(1),
    });
    if (exitCode !== 0) {
        process.exit(exitCode);
    }
};
