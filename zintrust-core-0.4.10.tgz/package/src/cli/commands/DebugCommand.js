/**
 * Debug Command
 * Launch debug mode with profiling and monitoring
 */
import { BaseCommand } from '../BaseCommand.js';
import { Dashboard } from '../debug/Dashboard.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
const addOptions = (command) => {
    command
        .option('--port <number>', 'Debug server port', '3000')
        .option('--enable-profiling', 'Enable memory profiling')
        .option('--enable-tracing', 'Enable request tracing');
};
const executeDebug = (cmd, options) => {
    cmd.info(`Debug command executed with options: ${JSON.stringify(options)}`);
    try {
        cmd.dashboard = Dashboard.create();
        cmd.dashboard.start();
        process.on('SIGINT', () => {
            cmd.dashboard?.stop();
            process.exit(0);
        });
    }
    catch (error) {
        cmd.dashboard?.stop();
        throw ErrorFactory.createTryCatchError(`Debug failed: ${error.message}`, error);
    }
};
/**
 * Debug Command
 * Launch debug mode with profiling and monitoring
 */
const create = () => {
    const ext = (options) => executeDebug(cmd, options);
    const cmd = BaseCommand.create({
        name: 'debug',
        description: 'Launch debug mode with real-time monitoring dashboard',
        addOptions,
        execute: ext,
    });
    cmd.dashboard = undefined;
    return cmd;
};
/**
 * Debug Command Factory
 */
export const DebugCommand = Object.freeze({
    /**
     * Create a new debug command instance
     */
    create,
});
