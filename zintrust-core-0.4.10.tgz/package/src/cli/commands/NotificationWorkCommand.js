/**
 * Notification Work Command
 * Alias to work a notification queue.
 */
import { createKindWorkCommand } from '../commands/createKindWorkCommand.js';
export const NotificationWorkCommand = Object.freeze({
    create() {
        return createKindWorkCommand({
            name: 'notification:work',
            description: 'Work queued notifications',
            kind: 'notification',
            helpHint: 'zin notification:work --help',
        });
    },
});
export default NotificationWorkCommand;
