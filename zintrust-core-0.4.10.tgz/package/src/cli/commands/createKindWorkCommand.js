import { BaseCommand } from '../BaseCommand.js';
import { QueueWorkCommandUtils } from '../commands/QueueWorkCommandUtils.js';
import { QueueWorkRunner } from '../workers/QueueWorkRunner.js';
export function createKindWorkCommand(options) {
    return BaseCommand.create({
        name: options.name,
        description: options.description,
        addOptions: (command) => {
            command
                .argument('<queueName>', 'Queue name to work')
                .option('--timeout <seconds>', 'Stop after this many seconds (default: 10)')
                .option('--retry <count>', 'Retries after first attempt (default: 3)')
                .option('--max-items <count>', 'Max items to process in one run (default: 1000)')
                .option('--driver <name>', 'Queue driver name (default: from QUEUE_DRIVER)');
        },
        execute: async (cmdOptions) => {
            const queueName = QueueWorkCommandUtils.requireQueueNameFromArgs(cmdOptions.args, options.helpHint);
            const timeoutSeconds = QueueWorkCommandUtils.parsePositiveInt(cmdOptions.timeout, '--timeout');
            const retry = QueueWorkCommandUtils.parseNonNegativeInt(cmdOptions.retry, '--retry');
            const maxItems = QueueWorkCommandUtils.parsePositiveInt(cmdOptions.maxItems, '--max-items');
            const driverName = QueueWorkCommandUtils.normalizeDriverName(cmdOptions.driver);
            const result = await QueueWorkRunner.run({
                kind: options.kind,
                queueName,
                timeoutSeconds,
                retry,
                maxItems,
                driverName,
            });
            QueueWorkCommandUtils.logSummary(queueName, options.kind, result);
        },
    });
}
