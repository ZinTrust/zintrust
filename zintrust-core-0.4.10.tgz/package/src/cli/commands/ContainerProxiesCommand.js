import { BaseCommand } from '../BaseCommand.js';
import { ContainerComposeLifecycle } from '../commands/ContainerComposeLifecycle.js';
import { resolveComposePath } from '../commands/DockerComposeCommandUtils.js';
const normalizeAction = (raw) => {
    return ContainerComposeLifecycle.normalizeAction(raw, ['build', 'up', 'down'], 'Usage: zin cp <build|up|down> [options]');
};
export const ContainerProxiesCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'cp',
            aliases: ['container-proxies'],
            description: 'Build, start, or stop container-based proxy stack',
            addOptions: (command) => {
                command.argument('<action>', 'Action to run (build, up, down)');
                command.option('-d, --detach', 'Run containers in background (up only)');
                command.option('--no-cache', 'Disable Docker build cache (build only)');
                command.option('--pull', 'Always attempt to pull a newer base image (build only)');
                command.option('--build', 'Build before running up (up only)');
                command.option('--remove-orphans', 'Remove containers for services not defined in compose');
                command.option('--volumes', 'Remove named volumes when running down (down only)');
            },
            execute: async (options) => {
                const action = normalizeAction(options.args?.[0]);
                const composePath = resolveComposePath('docker-compose.proxy.yml', 'docker-compose.proxy.yml not found.');
                if (action === 'build') {
                    await ContainerComposeLifecycle.runBuild(composePath, options, 'Building proxy stack image...');
                    return;
                }
                if (action === 'down') {
                    await ContainerComposeLifecycle.runDown(composePath, options, 'Stopping proxy stack...');
                    return;
                }
                if (options.build === true) {
                    await ContainerComposeLifecycle.runBuild(composePath, options, 'Building proxy stack image...');
                }
                await ContainerComposeLifecycle.runUp(composePath, options, 'Starting proxy stack...');
            },
        });
    },
});
