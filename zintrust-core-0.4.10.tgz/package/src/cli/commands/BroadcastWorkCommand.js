/**
 * Broadcast Work Command
 * Alias to work a broadcast queue.
 */
import { createKindWorkCommand } from '../commands/createKindWorkCommand.js';
export const BroadcastWorkCommand = Object.freeze({
    create() {
        return createKindWorkCommand({
            name: 'broadcast:work',
            description: 'Work queued broadcasts',
            kind: 'broadcast',
            helpHint: 'zin broadcast:work --help',
        });
    },
});
export default BroadcastWorkCommand;
