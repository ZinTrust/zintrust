/**
 * make:mail-template
 * Scaffolds a mail markdown template into the project.
 */
import { BaseCommand } from '../BaseCommand.js';
import { ErrorHandler } from '../ErrorHandler.js';
import { PromptHelper } from '../PromptHelper.js';
import { FileGenerator } from '../scaffolding/FileGenerator.js';
import { TemplateGenerator } from '../scaffolding/TemplateGenerator.js';
import { Env } from '../../config/env.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import * as path from '../../node-singletons/path.js';
const addOptions = (command) => {
    command.argument('[name]', 'Template name (alphanumeric + hyphens only)');
    command.option('--category <category>', 'auth|transactional|notifications');
    command.option('--vars <csv>', 'Comma-separated variables (e.g., name,confirmLink,expiryMinutes)');
    command.option('--overwrite', 'Overwrite existing file');
    command.option('--no-interactive', 'Disable prompts (requires args/options)');
};
const defaultCopyright = () => Env.TEMPLATE_COPYRIGHT;
export const MakeMailTemplateCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'make:mail-template',
            aliases: 'make:mail',
            description: 'Scaffold a mail markdown template into src/mail/markdown',
            addOptions,
            execute: async (options) => {
                const interactive = options.noInteractive !== true;
                const argName = options.args?.[0];
                const name = argName ??
                    (interactive ? await PromptHelper.textInput('Template name:', 'welcome', true) : '');
                if (name.trim() === '') {
                    throw ErrorFactory.createValidationError('Template name required');
                }
                const categoryInput = options.category ??
                    (interactive
                        ? await PromptHelper.chooseFrom('Category:', ['auth', 'transactional', 'notifications'], 'auth', true)
                        : 'auth');
                const category = categoryInput;
                const varsCsv = options.vars ??
                    (interactive
                        ? await PromptHelper.textInput('Variables (comma-separated):', 'name,confirmLink,expiryMinutes', true)
                        : '');
                const variables = TemplateGenerator.parseVariablesCsv(varsCsv);
                TemplateGenerator.ensureDirectories(process.cwd());
                // If file exists and overwrite not specified, ask.
                const desired = {
                    name,
                    category,
                    variables,
                    copyright: defaultCopyright(),
                    projectRoot: process.cwd(),
                    overwrite: options.overwrite === true,
                };
                if (options.overwrite !== true && interactive) {
                    const relPath = path.join('src', 'mail', 'markdown', category, `${name}.md`);
                    const fullPath = path.join(process.cwd(), relPath);
                    if (FileGenerator.fileExists(fullPath)) {
                        const confirm = await PromptHelper.confirm('File exists. Overwrite?', false, true);
                        if (confirm) {
                            desired.overwrite = true;
                        }
                    }
                }
                const result = TemplateGenerator.scaffoldMailMarkdownTemplate(desired);
                if (result.success) {
                    ErrorHandler.success(result.message);
                    return;
                }
                ErrorHandler.warn(result.message);
            },
        });
    },
});
export default MakeMailTemplateCommand;
