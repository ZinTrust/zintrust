import { BaseCommand } from '../BaseCommand.js';
import { SpawnUtil } from '../utils/spawn.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import * as path from '../../node-singletons/path.js';
import { ProxyRegistry } from '../../proxy/ProxyRegistry.js';
import '../../proxy/d1/register.js';
import '../../proxy/kv/register.js';
import '../../proxy/mysql/register.js';
import '../../proxy/postgres/register.js';
import '../../proxy/redis/register.js';
import '../../proxy/smtp/register.js';
const PROXY_TARGET_MAP = Object.freeze({
    mysql: 'proxy:mysql',
    my: 'proxy:mysql',
    postgres: 'proxy:postgres',
    postgresql: 'proxy:postgres',
    pg: 'proxy:postgres',
    redis: 'proxy:redis',
    smtp: 'proxy:smtp',
    mail: 'proxy:smtp',
    mongodb: 'proxy:mongodb',
    mongo: 'proxy:mongodb',
    sqlserver: 'proxy:sqlserver',
    mssql: 'proxy:sqlserver',
});
const addOptions = (command) => {
    command.argument('[target]', 'Proxy target (e.g. postgres, mysql, redis, smtp)');
};
const parseForwardArgs = () => {
    const argv = process.argv.slice(2);
    const proxyIndex = argv.indexOf('proxy');
    if (proxyIndex < 0) {
        return { target: null, extra: [] };
    }
    const target = argv[proxyIndex + 1] ?? null;
    const extra = argv.slice(proxyIndex + 2);
    return { target, extra };
};
const dispatchProxyTarget = async (targetRaw) => {
    const target = targetRaw.trim().toLowerCase();
    const mapped = PROXY_TARGET_MAP[target];
    if (!mapped) {
        throw ErrorFactory.createCliError(`Unknown proxy target '${targetRaw}'. Use one of: ${Object.keys(PROXY_TARGET_MAP).join(', ')}`);
    }
    const { extra } = parseForwardArgs();
    const exitCode = await SpawnUtil.spawnAndWait({
        command: 'tsx',
        args: [path.join('bin', 'zin.ts'), mapped, ...extra],
        env: {
            ...process.env,
        },
        forwardSignals: false,
    });
    process.exit(exitCode);
};
export const ProxyCommand = Object.freeze({
    create() {
        const cmd = BaseCommand.create({
            name: 'proxy',
            description: 'List available proxy servers',
            addOptions,
            execute: async (options) => {
                const firstArg = Array.isArray(options.args) ? options.args[0] : undefined;
                if (typeof firstArg === 'string' && firstArg.trim() !== '') {
                    await dispatchProxyTarget(firstArg);
                    return;
                }
                const list = ProxyRegistry.list();
                if (list.length === 0) {
                    throw ErrorFactory.createCliError('No proxies registered');
                }
                for (const proxy of list) {
                    cmd.info(`${proxy.name}: ${proxy.description}`);
                }
            },
        });
        return cmd;
    },
});
export default ProxyCommand;
