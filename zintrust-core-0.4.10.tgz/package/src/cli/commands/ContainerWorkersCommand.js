import { BaseCommand } from '../BaseCommand.js';
import { ContainerComposeLifecycle } from '../commands/ContainerComposeLifecycle.js';
import { resolveComposePath } from '../commands/DockerComposeCommandUtils.js';
const normalizeAction = (raw) => {
    return ContainerComposeLifecycle.normalizeAction(raw, ['build', 'up'], 'Usage: zin cw <build|up> [options]');
};
export const ContainerWorkersCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'cw',
            aliases: ['container-workers'],
            description: 'Build or start container-based workers',
            addOptions: (command) => {
                command.argument('<action>', 'Action to run (build, up)');
                command.option('-d, --detach', 'Run containers in background (up only)');
                command.option('--no-cache', 'Disable Docker build cache (build only)');
                command.option('--pull', 'Always attempt to pull a newer base image (build only)');
                command.option('--build', 'Build before running up (up only)');
            },
            execute: async (options) => {
                const action = normalizeAction(options.args?.[0]);
                const composePath = resolveComposePath('docker-compose.workers.yml', 'docker-compose.workers.yml not found. Run `zin init:cw` first.');
                if (action === 'build') {
                    await ContainerComposeLifecycle.runBuild(composePath, options, 'Building container workers image...');
                    return;
                }
                if (options.build === true) {
                    await ContainerComposeLifecycle.runBuild(composePath, options, 'Building container workers image...');
                }
                await ContainerComposeLifecycle.runUp(composePath, options, 'Starting container workers...');
            },
        });
    },
});
