import { runComposeWithFallback } from '../commands/DockerComposeCommandUtils.js';
import { Logger } from '../../config/logger.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
export const ContainerComposeLifecycle = Object.freeze({
    normalizeAction(raw, allowed, usageMessage) {
        const value = (raw ?? '').trim().toLowerCase();
        for (const item of allowed) {
            if (value === item)
                return item;
        }
        throw ErrorFactory.createCliError(usageMessage);
    },
    async runBuild(composePath, options, logMessage) {
        const args = ['compose', '-f', composePath, 'build'];
        if (options.noCache === true) {
            args.push('--no-cache');
        }
        if (options.pull === true) {
            args.push('--pull');
        }
        Logger.info(logMessage);
        await runComposeWithFallback(args);
    },
    async runUp(composePath, options, logMessage) {
        const args = ['compose', '-f', composePath, 'up'];
        if (options.detach === true) {
            args.push('-d');
        }
        if (options.removeOrphans === true) {
            args.push('--remove-orphans');
        }
        Logger.info(logMessage);
        await runComposeWithFallback(args);
    },
    async runDown(composePath, options, logMessage) {
        const args = ['compose', '-f', composePath, 'down'];
        if (options.volumes === true) {
            args.push('-v');
        }
        if (options.removeOrphans === true) {
            args.push('--remove-orphans');
        }
        Logger.info(logMessage);
        await runComposeWithFallback(args);
    },
});
