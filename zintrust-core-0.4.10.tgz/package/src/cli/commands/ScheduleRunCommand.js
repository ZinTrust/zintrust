import { BaseCommand } from '../BaseCommand.js';
import { ScheduleCliSupport } from '../commands/schedule/ScheduleCliSupport.js';
import { Logger } from '../../config/logger.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { SchedulerRuntime } from '../../scheduler/SchedulerRuntime.js';
const execute = async (options) => {
    const name = (options.name ?? '').trim();
    if (name.length === 0)
        throw ErrorFactory.createConfigError('--name is required');
    try {
        await ScheduleCliSupport.registerAll();
        Logger.info('Running schedule once', { name });
        await SchedulerRuntime.runOnce(name);
        Logger.info('Schedule run completed', { name });
    }
    finally {
        await ScheduleCliSupport.shutdownCliResources();
    }
};
export const ScheduleRunCommand = Object.freeze({
    create() {
        return BaseCommand.create({
            name: 'schedule:run',
            description: 'Run a specific schedule once and exit',
            addOptions: (command) => {
                command.option('--name <name>', 'Schedule name to run');
            },
            execute,
        });
    },
});
export default ScheduleRunCommand;
