import { isObject } from '../helper/index.js';
const globalWithRegistry = globalThis;
const registry = globalWithRegistry.__zintrust_cli_command_registry__ ??
    (globalWithRegistry.__zintrust_cli_command_registry__ = new Map());
const isCliCommandProvider = (value) => {
    return isObject(value) && typeof value['getCommand'] === 'function';
};
const normalizeId = (id) => id.trim();
export const OptionalCliCommandRegistry = Object.freeze({
    register(id, provider) {
        const normalizedId = normalizeId(id);
        if (normalizedId === '' || !isCliCommandProvider(provider))
            return;
        registry.set(normalizedId, provider);
    },
    get(id) {
        return registry.get(normalizeId(id));
    },
    has(id) {
        return registry.has(normalizeId(id));
    },
    list() {
        return Array.from(registry.values());
    },
});
