/**
 * Debug Dashboard
 * Terminal-based real-time monitoring UI
 */
import { randomInt } from '../../node-singletons/crypto.js';
import * as os from '../../node-singletons/os.js';
import * as readline from '../../node-singletons/readline.js';
import chalk from 'chalk';
const formatBytes = (bytes) => {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let i = 0;
    while (size > 1024 && i < units.length - 1) {
        size /= 1024;
        i++;
    }
    return `${size.toFixed(2)} ${units[i]}`;
};
const formatDuration = (seconds) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}h ${m}m ${s}s`;
};
const getPercent = (value, total) => {
    return ((value / total) * 100).toFixed(1);
};
const hideCursor = () => {
    process.stdout.write('\x1B[?25l');
};
const showCursor = () => {
    process.stdout.write('\x1B[?25h');
};
const renderSection = (title, lines) => {
    process.stdout.write(chalk.cyan.bold(`\n[ ${title} ]`) + '\n');
    lines.forEach((line) => process.stdout.write(`  ${line}\n`));
};
const render = (stats) => {
    readline.cursorTo(process.stdout, 0, 0);
    const header = chalk.bgBlue.white.bold(' ZINTRUST DEBUG DASHBOARD ');
    const uptime = chalk.gray(`Uptime: ${formatDuration(stats.uptime)}`);
    process.stdout.write(`${header} ${uptime}\n\n`);
    renderSection('SYSTEM RESOURCES', [
        `Memory: ${formatBytes(stats.memory.used)} / ${formatBytes(stats.memory.total)} (${getPercent(stats.memory.used, stats.memory.total)}%)`,
        `CPU Load: ${os.loadavg()[0].toFixed(2)}`,
    ]);
    renderSection('HTTP REQUESTS', [
        `Total Requests: ${stats.requests.total}`,
        `Active Requests: ${chalk.green(stats.requests.active)}`,
        `Avg Duration: ${stats.requests.avgDuration}ms`,
    ]);
    renderSection('DATABASE QUERIES', [
        `Total Queries: ${stats.queries.total}`,
        `N+1 Warnings: ${stats.queries.n1Warnings > 0 ? chalk.red.bold(stats.queries.n1Warnings) : chalk.green('0')}`,
    ]);
    process.stdout.write('\n' + chalk.gray('Press Ctrl+C to exit') + '\n');
};
const updateStatsInternal = (stats) => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    stats.uptime = process.uptime();
    stats.memory = {
        total: totalMem,
        free: freeMem,
        used: totalMem - freeMem,
    };
    // Mock some activity for demonstration
    if (randomInt(0, 1000) > 700) {
        stats.requests.total += randomInt(0, 3);
        stats.requests.active = randomInt(0, 5);
        stats.requests.avgDuration = randomInt(20, 120);
    }
    if (randomInt(0, 1000) > 800) {
        stats.queries.total += randomInt(0, 10);
        if (randomInt(0, 1000) > 900) {
            stats.queries.n1Warnings++;
        }
    }
};
/**
 * Debug Dashboard
 * Terminal-based real-time monitoring UI
 * Sealed namespace for immutability
 */
const DashboardFactory = Object.freeze({
    create() {
        const state = {
            rl: readline.createInterface({
                input: process.stdin,
                output: process.stdout,
            }),
            stats: {
                uptime: 0,
                memory: { total: 0, free: 0, used: 0 },
                requests: { total: 0, active: 0, avgDuration: 0 },
                queries: { total: 0, n1Warnings: 0 },
            },
            timer: undefined,
        };
        const dashboard = {
            render() {
                render(state.stats);
            },
            updateStats() {
                updateStatsInternal(state.stats);
            },
            /**
             * Start the dashboard
             */
            start() {
                process.stdout.write('\x1Bc'); // Clear screen
                hideCursor();
                dashboard.render();
                if (state.timer) {
                    clearInterval(state.timer);
                }
                state.timer = setInterval(() => {
                    dashboard.updateStats();
                    dashboard.render();
                }, 1000);
                // Ensure cleanup on exit
                const cleanup = () => {
                    dashboard.stop();
                    process.exit(0);
                };
                process.on('SIGINT', cleanup);
                process.on('SIGTERM', cleanup);
            },
            /**
             * Stop the dashboard
             */
            stop() {
                if (state.timer) {
                    clearInterval(state.timer);
                }
                showCursor();
                state.rl.close();
            },
            /**
             * Update dashboard stats
             */
            update(newStats) {
                state.stats = { ...state.stats, ...newStats };
            },
        };
        return dashboard;
    },
});
const DashboardCallable = function DashboardCallable() {
    return DashboardFactory.create();
};
export const Dashboard = Object.assign(DashboardCallable, DashboardFactory);
