/**
 * Validation Error
 * Structured error response for validation failures with field-level details
 */
import { ErrorFactory } from '../exceptions/ZintrustError.js';
/**
 * Convert errors array to field:errors object
 */
export const toObject = (errors) => {
    const result = {};
    const MAX_ERRORS_PER_FIELD = 10;
    for (const error of errors) {
        result[error.field] ??= [];
        if (result[error.field].length < MAX_ERRORS_PER_FIELD) {
            result[error.field].push(error.message);
        }
    }
    return result;
};
/**
 * Get first error message for a field
 */
export const getFieldError = (errors, field) => {
    return errors.find((e) => e.field === field)?.message;
};
/**
 * Check if field has errors
 */
export const hasFieldError = (errors, field) => {
    return errors.some((e) => e.field === field);
};
/**
 * Create a validation error instance
 */
const createValidationError = (errors, message = 'Validation failed') => {
    const error = ErrorFactory.createValidationError(message, {
        errors,
    });
    error.errors = errors;
    error.toObject = () => toObject(errors);
    error.getFieldError = (field) => getFieldError(errors, field);
    error.hasFieldError = (field) => hasFieldError(errors, field);
    return error;
};
/**
 * ValidationError namespace - sealed for immutability
 */
export const ValidationError = Object.freeze({
    create: createValidationError,
    toObject,
    getFieldError,
    hasFieldError,
});
// For backward compatibility with existing imports
export { createValidationError };
