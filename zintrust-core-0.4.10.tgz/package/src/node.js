import { Logger } from './config/logger.js';
// Runtime marker to make this re-export-only module coverable in V8 coverage.
const __coverageMarker = true;
if (__coverageMarker !== true) {
    throw Logger.error('Unreachable');
}
export * as crypto from './node-singletons/crypto.js';
export * as fs from './node-singletons/fs.js';
export * as path from './node-singletons/path.js';
export { performance } from './node-singletons/perf-hooks.js';
export { default, default as process } from './node-singletons/process.js';
export * as url from './node-singletons/url.js';
export { cleanOnce, FileLogWriter } from './config/FileLogWriter.js';
export { listTemplates, loadTemplate, renderTemplate } from './tools/mail/templates/index.js';
export { MailFake } from './tools/mail/testing.js';
export { FakeStorage } from './tools/storage/testing.js';
export { TestEnvironment, TestHttp } from './testing/index.js';
export { listTemplates as listNotificationTemplates, loadTemplate as loadNotificationTemplate, renderTemplate as renderNotificationTemplate, } from './tools/notification/templates/markdown/index.js';
