import { MigratorFactory } from './MigratorFactory.js';
export const Migrator = Object.freeze({
    create: MigratorFactory.create,
});
