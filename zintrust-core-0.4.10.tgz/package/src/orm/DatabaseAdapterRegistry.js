const globalWithRegistry = globalThis;
const registry = globalWithRegistry.__zintrust_db_adapter_registry__ ??
    (globalWithRegistry.__zintrust_db_adapter_registry__ = new Map());
function register(driver, factory) {
    registry.set(driver, factory);
}
function get(driver) {
    return registry.get(driver);
}
function has(driver) {
    return registry.has(driver);
}
function list() {
    return Array.from(registry.keys());
}
export const DatabaseAdapterRegistry = Object.freeze({
    register,
    get,
    has,
    list,
});
