/**
 * Database Adapter Interface
 * Defines contract for different database implementations
 */
/**
 * Base Adapter Utilities
 * Refactored to Functional Object pattern
 */
export const BaseAdapter = Object.freeze({
    /**
     * Sanitize parameter value
     */
    sanitize(value) {
        if (value === null || value === undefined) {
            return 'NULL';
        }
        if (typeof value === 'string') {
            return `'${value.replaceAll("'", "''")}'`;
        }
        if (typeof value === 'boolean') {
            return value ? '1' : '0';
        }
        // Support BigInt explicitly to avoid JSON.stringify errors and driver issues
        if (typeof value === 'bigint') {
            return String(value);
        }
        // Dates should be passed as ISO strings
        if (value instanceof Date) {
            return `'${value.toISOString()}'`;
        }
        if (typeof value === 'number') {
            return String(value);
        }
        // Buffer / Uint8Array -> base64 string
        // Some DB adapters expect binary types; returning base64-encoded string is a safe default
        // and prevents JSON.stringify(BigInt) errors when objects include BigInt.
        if (typeof Buffer !== 'undefined' && Buffer.isBuffer(value)) {
            return `'${value.toString('base64')}'`;
        }
        if (value instanceof Uint8Array) {
            return `'${Buffer.from(value).toString('base64')}'`;
        }
        // For objects, convert to JSON string representation
        return `'${JSON.stringify(value).replaceAll("'", "''")}'`;
    },
    /**
     * Build parameterized query (for adapters that need it)
     */
    buildParameterizedQuery(sql, parameters, getPlaceholder = () => '?') {
        let paramIndex = 0;
        const processedSql = sql.replaceAll('?', () => {
            paramIndex++;
            return getPlaceholder(paramIndex);
        });
        return { sql: processedSql, parameters };
    },
});
