import { ErrorFactory } from '../../exceptions/ZintrustError.js';
const supportsResetSchema = (adapter) => typeof adapter.resetSchema === 'function';
export const SqliteMaintenance = Object.freeze({
    async dropAllTables(db) {
        if (db.getType() !== 'sqlite') {
            throw ErrorFactory.createDatabaseError('dropAllTables is only supported for sqlite');
        }
        const adapter = db.getAdapterInstance(false);
        if (!supportsResetSchema(adapter)) {
            throw ErrorFactory.createDatabaseError('SQLite adapter does not support resetSchema()');
        }
        await adapter.resetSchema();
    },
});
