/* eslint-disable @typescript-eslint/require-await */
/**
 * SQL Server Database Adapter
 */
import { FeatureFlags } from '../../config/features.js';
import { Logger } from '../../config/logger.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { AdaptersEnum } from '../../migrations/enum/index.js';
import { QueryBuilder } from '../QueryBuilder.js';
/**
 * SQL Server adapter implementation
 * Sealed namespace for immutability
 */
export const SQLServerAdapter = Object.freeze({
    /**
     * Create a new SQL Server adapter instance
     */
    create(config) {
        let connected = false;
        return {
            async connect() {
                if (config.host === 'error') {
                    throw ErrorFactory.createConnectionError('Failed to connect to SQL Server: Error: Connection failed');
                }
                connected = true;
                Logger.info(`✓ SQL Server connected (${config.host}:${config.port})`);
            },
            async disconnect() {
                connected = false;
                Logger.info('✓ SQL Server disconnected');
            },
            async query(_sql, _parameters) {
                if (!connected)
                    throw ErrorFactory.createConnectionError('Database not connected');
                // Mock implementation
                return { rows: [], rowCount: 0 };
            },
            async queryOne(sql, parameters) {
                const result = await this.query(sql, parameters);
                return result.rows[0] ?? null;
            },
            async ping() {
                await this.query(QueryBuilder.create('').select('1').toSQL(), []);
            },
            async transaction(callback) {
                try {
                    return await callback(this);
                }
                catch (error) {
                    throw ErrorFactory.createTryCatchError('Transaction failed', error);
                }
            },
            getType() {
                return AdaptersEnum.sqlserver;
            },
            isConnected() {
                return connected;
            },
            async rawQuery(sql, parameters) {
                if (!FeatureFlags.isRawQueryEnabled()) {
                    throw ErrorFactory.createConfigError('Raw SQL queries are disabled. Set USE_RAW_QRY=true environment variable to enable.');
                }
                if (!connected) {
                    throw ErrorFactory.createConnectionError('Database not connected');
                }
                Logger.warn(`Raw SQL Query executed: ${sql}`, { parameters });
                try {
                    if (sql.toUpperCase().includes('INVALID')) {
                        throw ErrorFactory.createDatabaseError('Invalid SQL syntax');
                    }
                    // Mock implementation
                    return [];
                }
                catch (error) {
                    throw ErrorFactory.createTryCatchError('Raw SQL Query failed', error);
                }
            },
            getPlaceholder(index) {
                return `@param${index}`;
            },
        };
    },
});
export default SQLServerAdapter;
