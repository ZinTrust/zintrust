const CACHE_TTL_MS = 5000;
export const ProxyCache = Object.freeze({
    create() {
        const cache = new Map();
        return Object.freeze({
            get(key) {
                const entry = cache.get(key);
                if (!entry)
                    return null;
                if (Date.now() - entry.timestamp > CACHE_TTL_MS) {
                    cache.delete(key);
                    return null;
                }
                return entry.data;
            },
            set(key, data) {
                cache.set(key, { data, timestamp: Date.now() });
            },
            clear() {
                cache.clear();
            },
        });
    },
});
