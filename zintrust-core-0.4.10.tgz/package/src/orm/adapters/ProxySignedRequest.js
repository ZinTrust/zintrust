import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { normalizeSigningCredentials } from '../../proxy/SigningService.js';
import { SignedRequest } from '../../security/SignedRequest.js';
import { buildSigningUrl } from '../adapters/ProxySigningPath.js';
export const createSignedProxyRequest = async (input) => {
    const creds = normalizeSigningCredentials({ keyId: input.keyId, secret: input.secret });
    if (creds.keyId.trim() === '' || creds.secret.trim() === '') {
        throw ErrorFactory.createConfigError(input.missingCredentialsMessage);
    }
    const urlObj = new URL(input.url);
    const signingUrl = buildSigningUrl(urlObj, input.url);
    const signResult = await SignedRequest.createHeaders({
        method: 'POST',
        url: signingUrl,
        body: input.body,
        keyId: creds.keyId,
        secret: creds.secret,
    });
    return {
        headers: {
            'content-type': 'application/json',
            'x-zt-key-id': signResult['x-zt-key-id'],
            'x-zt-timestamp': signResult['x-zt-timestamp'],
            'x-zt-nonce': signResult['x-zt-nonce'],
            'x-zt-body-sha256': signResult['x-zt-body-sha256'],
            'x-zt-signature': signResult['x-zt-signature'],
        },
        body: input.body,
    };
};
