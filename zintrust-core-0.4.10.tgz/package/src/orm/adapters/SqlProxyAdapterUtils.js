import { RemoteSignedJson } from '../../common/RemoteSignedJson.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { isObject } from '../../helper/index.js';
import { resolveSigningPrefix } from '../adapters/ProxySigningPath.js';
import { normalizeSigningCredentials } from '../../proxy/SigningService.js';
export const buildSignedSettings = (config) => {
    const creds = normalizeSigningCredentials({
        keyId: config.settings.keyId ?? '',
        secret: config.settings.secret ?? '',
    });
    return {
        baseUrl: config.settings.baseUrl,
        keyId: creds.keyId,
        secret: creds.secret,
        timeoutMs: config.settings.timeoutMs,
        signaturePathPrefixToStrip: config.settings.signaturePathPrefixToStrip ?? resolveSigningPrefix(config.settings.baseUrl),
        missingUrlMessage: config.missingUrlMessage,
        missingCredentialsMessage: config.missingCredentialsMessage,
        messages: config.messages,
    };
};
export const ensureSignedSettings = (config) => {
    const signedSettings = buildSignedSettings(config);
    if (signedSettings.baseUrl.trim() === '') {
        throw ErrorFactory.createConfigError(config.missingUrlMessage);
    }
    if (signedSettings.keyId.trim() === '' || signedSettings.secret.trim() === '') {
        throw ErrorFactory.createConfigError(config.missingCredentialsMessage);
    }
    return signedSettings;
};
export const requestSignedProxy = async (config, path, payload) => {
    const signedSettings = ensureSignedSettings(config);
    return RemoteSignedJson.request(signedSettings, path, payload);
};
export const isRecord = (value) => isObject(value);
