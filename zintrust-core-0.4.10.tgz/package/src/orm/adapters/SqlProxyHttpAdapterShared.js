import { Env } from '../../config/env.js';
import { ErrorFactory } from '../../exceptions/ZintrustError.js';
import { ensureSignedSettings, requestSignedProxy, } from '../adapters/SqlProxyAdapterUtils.js';
import { resolveSqlProxyMode } from '../adapters/SqlProxyRegistryMode.js';
const resolveBaseUrl = (input) => {
    const explicit = Env.get(input.urlKey, '').trim();
    if (explicit !== '')
        return explicit;
    if (input.hostKey === undefined ||
        input.portKey === undefined ||
        input.defaultPort === undefined) {
        return '';
    }
    const defaultHost = input.defaultHost ?? '127.0.0.1';
    const rawHost = Env.get(input.hostKey, defaultHost);
    const host = typeof rawHost === 'string' && rawHost.trim() !== '' ? rawHost : defaultHost;
    const port = Env.getInt(input.portKey, input.defaultPort);
    return `http://${host}:${port}`;
};
const buildProxySettingsFromEnv = (input) => {
    const baseUrl = resolveBaseUrl(input);
    const keyId = Env.get(input.keyIdKey, Env.get(input.sharedKeyIdKey ?? 'ZT_PROXY_KEY_ID', ''));
    const secret = Env.get(input.secretKey, Env.get(input.sharedSecretKey ?? 'ZT_PROXY_SECRET', ''));
    const timeoutMs = Env.getInt(input.timeoutKey, Env.getInt(input.sharedTimeoutKey ?? 'ZT_PROXY_TIMEOUT_MS', 30000));
    return { baseUrl, keyId, secret, timeoutMs };
};
const buildStandardSignedProxyConfig = (input) => {
    const { settings, label } = input;
    const prefix = `${label} proxy`;
    return {
        settings,
        missingUrlMessage: `${label} proxy URL is missing (${input.urlKey})`,
        missingCredentialsMessage: `${label} proxy signing credentials are missing (${input.keyIdKey} / ${input.secretKey})`,
        messages: {
            unauthorized: `${prefix} unauthorized`,
            forbidden: `${prefix} forbidden`,
            rateLimited: `${prefix} rate limited`,
            rejected: `${prefix} rejected request`,
            error: `${prefix} error`,
            timedOut: `${prefix} request timed out`,
        },
    };
};
const ensureSignedProxyConfig = (signed) => {
    ensureSignedSettings(signed);
};
const requestProxy = async (signed, path, payload) => {
    return requestSignedProxy(signed, path, payload);
};
const resolveProxyModeFromEnv = (envKey) => {
    return resolveSqlProxyMode(envKey);
};
const createProxyNotReachableCliError = (label, baseUrl, error) => {
    const msg = error instanceof Error ? error.message : String(error);
    return ErrorFactory.createCliError(`${label} is enabled but the proxy server is not reachable at ${baseUrl}. Start the proxy stack (e.g. \`zin cp up\` or \`docker compose -f docker-compose.proxy.yml up -d\`) and re-run \`zin migrate\`.`, { error: msg, baseUrl });
};
export const SqlProxyHttpAdapterShared = Object.freeze({
    buildProxySettingsFromEnv,
    buildStandardSignedProxyConfig,
    ensureSignedProxyConfig,
    requestProxy,
    resolveProxyModeFromEnv,
    createProxyNotReachableCliError,
});
