import { Env } from '../../config/env.js';
import { isRecord } from '../adapters/SqlProxyAdapterUtils.js';
import { SignedRequest } from '../../security/SignedRequest.js';
export const resolveSqlProxyMode = (envKey) => {
    const raw = Env.get(envKey, 'sql').trim().toLowerCase();
    return raw === 'registry' ? 'registry' : 'sql';
};
export const createStatementId = async (sql) => {
    return SignedRequest.sha256Hex(sql);
};
export const createStatementPayload = async (sql, parameters) => {
    const statementId = await createStatementId(sql);
    return { statementId, params: parameters };
};
export const getExecMetaWithLastRowId = (value) => {
    if (!isRecord(value) || typeof value['ok'] !== 'boolean')
        return { changes: 0 };
    const meta = value['meta'];
    if (!isRecord(meta))
        return { changes: 0 };
    const changes = typeof meta['changes'] === 'number' ? meta['changes'] : 0;
    const lastRowId = meta['lastRowId'];
    return { changes, lastRowId: lastRowId };
};
