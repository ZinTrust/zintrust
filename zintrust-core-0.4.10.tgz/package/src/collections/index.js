export { collect, Collection } from './Collection.js';
