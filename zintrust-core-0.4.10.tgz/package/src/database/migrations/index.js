// Placeholder for migrations
export const migrations = Object.freeze([]);
