/**
 * Profiling Type Definitions
 * Shared interfaces for query logging, N+1 detection, and memory profiling
 */
export const PROFILING_TYPES_MODULE = Object.freeze('ProfilingTypes');
