/**
 * Request Profiler
 * Comprehensive profiling of request execution combining query, N+1, and memory metrics
 */
import { MemoryProfiler } from './MemoryProfiler.js';
import { N1Detector } from './N1Detector.js';
import { QueryLogger } from './QueryLogger.js';
/**
 * RequestProfiler orchestrates query logging, N+1 detection, and memory profiling
 * Sealed namespace for immutability
 */
export const RequestProfiler = Object.freeze({
    /**
     * Create a new request profiler instance
     */
    create() {
        const queryLogger = QueryLogger.getInstance();
        const n1Detector = N1Detector.create();
        const memoryProfiler = MemoryProfiler.create();
        let startTime = 0;
        let endTime = 0;
        return {
            getQueryLogger() {
                return queryLogger;
            },
            getN1Detector() {
                return n1Detector;
            },
            getMemoryProfiler() {
                return memoryProfiler;
            },
            async captureRequest(fn) {
                // Start profiling
                startTime = Date.now();
                memoryProfiler.start();
                queryLogger.setContext('profiling');
                try {
                    // Execute the request
                    await fn();
                }
                finally {
                    // End profiling
                    endTime = Date.now();
                    memoryProfiler.end();
                }
                // Gather profiling data
                const duration = endTime - startTime;
                const queryLog = queryLogger.getQueryLog('profiling');
                const queriesExecuted = queryLog.length;
                const patterns = n1Detector.detect(queryLog);
                const memoryDelta = memoryProfiler.delta();
                const report = {
                    duration,
                    queriesExecuted,
                    n1Patterns: patterns,
                    memoryDelta,
                    timestamp: new Date(),
                };
                queryLogger.clear('profiling');
                return report;
            },
            generateReport(profile) {
                const n1Section = formatN1Section(profile.n1Patterns);
                const lines = [
                    '=== Performance Profile Report ===',
                    `\nTiming: ${profile.duration}ms`,
                    `Queries: ${profile.queriesExecuted}`,
                    ...n1Section,
                    '\nMemory Delta:',
                    `  Heap Used: ${MemoryProfiler.formatBytes(profile.memoryDelta.heapUsed)}`,
                    `  Heap Total: ${MemoryProfiler.formatBytes(profile.memoryDelta.heapTotal)}`,
                    `  External: ${MemoryProfiler.formatBytes(profile.memoryDelta.external)}`,
                    `  RSS: ${MemoryProfiler.formatBytes(profile.memoryDelta.rss)}`,
                ];
                return lines.join('\n');
            },
        };
    },
});
/**
 * Format N+1 section for report
 */
function formatN1Section(patterns) {
    if (patterns.length === 0) {
        return ['\nN+1 Patterns: None detected'];
    }
    return [
        '\nN+1 Patterns:',
        ...patterns.map((pattern) => `  [${pattern.severity.toUpperCase()}] "${pattern.table}": ${pattern.queryCount}x`),
    ];
}
/**
 * Re-export MemoryProfiler's static formatBytes for convenience
 */
export { MemoryProfiler } from './MemoryProfiler.js';
export default RequestProfiler;
