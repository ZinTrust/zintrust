/**
 * Core Routes - Framework built-in routes
 * Health, metrics, and documentation endpoints
 * Not customizable by developers; provide env-based configuration
 */
import { PrometheusMetrics } from '../observability/PrometheusMetrics.js';
import { registerOpenApiRoutes } from '../routes/openapi.js';
import { registerHealthRoutes } from '../common/HealthRoutes.js';
import { Env } from '../config/env.js';
import { registerDocRoutes } from './doc.js';
import { registerErrorRoutes } from './error.js';
import { registerErrorPagesRoutes } from './errorPages.js';
import { Router } from './Router.js';
/**
 * Register metrics endpoint
 */
const registerMetricsRoutes = (router) => {
    if (Env.getBool('METRICS_ENABLED', false) === false)
        return;
    const pathFromEnv = Env.get('METRICS_PATH', '/metrics').trim();
    const metricsPath = pathFromEnv === '' ? '/metrics' : pathFromEnv;
    Router.get(router, metricsPath, async (_req, res) => {
        const { contentType, body } = await PrometheusMetrics.getMetricsText();
        res.setHeader('Content-Type', contentType);
        res.send(body);
    });
};
/**
 * Register all core framework routes
 */
export const registerCoreRoutes = (router) => {
    registerHealthRoutes(router);
    registerMetricsRoutes(router);
    registerDocRoutes(router);
    registerErrorPagesRoutes(router);
    registerErrorRoutes(router);
    registerOpenApiRoutes(router);
};
export default registerCoreRoutes;
