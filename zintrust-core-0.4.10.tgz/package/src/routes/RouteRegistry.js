export const normalizeRouteMeta = (input) => {
    if (input === undefined)
        return undefined;
    // If it already looks like the normalized shape, return as-is.
    if (typeof input === 'object' &&
        input !== null &&
        ('request' in input || 'response' in input || 'summary' in input || 'tags' in input)) {
        const any = input;
        return any;
    }
    const any = input;
    return {
        summary: any.summary,
        description: any.description,
        tags: any.tags,
        request: any.requestSchema === undefined
            ? undefined
            : {
                bodySchema: any.requestSchema,
            },
        response: any.responseSchema === undefined && any.responseStatus === undefined
            ? undefined
            : {
                status: any.responseStatus,
                schema: any.responseSchema,
            },
    };
};
const state = {
    routes: [],
};
export const RouteRegistry = Object.freeze({
    record(route) {
        state.routes.push(route);
    },
    list() {
        // Return readonly reference to avoid unnecessary array cloning
        return state.routes;
    },
    clear() {
        state.routes.length = 0;
    },
});
export default RouteRegistry;
