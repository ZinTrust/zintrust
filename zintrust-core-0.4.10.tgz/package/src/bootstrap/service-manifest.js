export const serviceManifest = [];
export default serviceManifest;
