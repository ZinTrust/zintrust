/**
 * Application Configuration
 * Core application settings
 * Sealed namespace for immutability
 */
import { Env } from './env.js';
// Cache getSafeEnv result at module load time to avoid repeated object creation
const anyEnv = Env;
const readEnvString = (key, defaultValue = '') => {
    if (typeof anyEnv.get === 'function') {
        return anyEnv.get(key, defaultValue) ?? '';
    }
    if (typeof process !== 'undefined') {
        const raw = process.env?.[key];
        if (typeof raw === 'string' && raw !== '')
            return raw;
    }
    return defaultValue;
};
const readEnvInt = (key, defaultValue = 0) => {
    if (typeof anyEnv.getInt === 'function') {
        return anyEnv.getInt(key, defaultValue);
    }
    const raw = readEnvString(key, String(defaultValue));
    const parsed = Number.parseInt(raw, 10);
    return Number.isFinite(parsed) ? parsed : defaultValue;
};
const readEnvBool = (key, defaultValue = false) => {
    if (typeof anyEnv.getBool === 'function') {
        return anyEnv.getBool(key, defaultValue);
    }
    const raw = readEnvString(key, '');
    if (raw === '')
        return defaultValue;
    return raw.toLowerCase() === 'true' || raw === '1';
};
const readAppPort = () => {
    if (typeof anyEnv.getInt === 'function') {
        return anyEnv.getInt('PORT', anyEnv.getInt('APP_PORT', 3000));
    }
    if (typeof Env.PORT === 'number' && Number.isFinite(Env.PORT) && Env.PORT > 0) {
        return Env.PORT;
    }
    const portRaw = readEnvString('PORT', readEnvString('APP_PORT', '3000'));
    const parsed = Number.parseInt(portRaw, 10);
    return Number.isFinite(parsed) ? parsed : 3000;
};
/**
 * Check if running on AWS Lambda
 */
function isLambda() {
    return (Env.getBool('LAMBDA_TASK_ROOT') === true ||
        Env.getBool('AWS_LAMBDA_FUNCTION_NAME') === true ||
        Env.getBool('AWS_EXECUTION_ENV') === true);
}
/**
 * Check if running on Cloudflare Workers
 */
function isCloudflare() {
    return globalThis.CF !== undefined;
}
/**
 * Check if running on Deno
 */
function isDeno() {
    return globalThis.Deno !== undefined;
}
/**
 * Detect current runtime environment
 */
const detectRuntime = () => {
    const explicit = Env.get('RUNTIME').trim();
    if (explicit !== '' && explicit !== 'auto')
        return explicit;
    // Auto-detection logic
    if (isLambda() === true) {
        return 'lambda';
    }
    if (isCloudflare() === true) {
        return 'cloudflare';
    }
    if (isDeno() === true) {
        return 'deno';
    }
    // Default to nodejs for containers (Fargate, Docker, Cloud Run)
    return 'nodejs';
};
const resolvedNodeEnv = readEnvString('NODE_ENV', 'development');
// Cache getSafeEnv result at module load time to avoid repeated object creation
const cachedSafeEnv = {
    ...(typeof process === 'undefined' ? {} : process.env),
    NODE_ENV: resolvedNodeEnv,
    MODE: resolvedNodeEnv,
    npm_config_scripts_prepend_node_path: 'true',
};
const useRawQry = readEnvString('USE_RAW_QRY');
if (useRawQry !== '')
    cachedSafeEnv.USE_RAW_QRY = useRawQry;
const serviceApiKey = readEnvString('SERVICE_API_KEY');
if (serviceApiKey !== '')
    cachedSafeEnv.SERVICE_API_KEY = serviceApiKey;
const serviceJwtSecret = readEnvString('SERVICE_JWT_SECRET') || readEnvString('APP_KEY');
if (serviceJwtSecret !== '')
    cachedSafeEnv.SERVICE_JWT_SECRET = serviceJwtSecret;
const baseUrl = readEnvString('BASE_URL');
if (baseUrl !== '')
    cachedSafeEnv['BASE_URL'] = baseUrl;
if (typeof Env.SAFE_PATH === 'string' && Env.SAFE_PATH !== '') {
    cachedSafeEnv['PATH'] = Env.SAFE_PATH;
}
const getSafeEnv = () => cachedSafeEnv;
const normalizeMode = () => {
    const value = readEnvString('NODE_ENV', Env.NODE_ENV ?? 'development');
    if (value === 'production' || value === 'pro' || value === 'prod')
        return 'production';
    if (value === 'testing' || value === 'test')
        return 'testing';
    return 'development';
};
const Prefix = () => {
    const app_name = (Env.APP_NAME || 'zintrust').toLowerCase().replaceAll(/\s/g, '_');
    const env = Env.NODE_ENV;
    return `${app_name}_zintrust_${env}`;
};
const appConfigObj = {
    /**
     * Application name
     */
    name: readEnvString('APP_NAME', Env.APP_NAME),
    /**
     * Application prefix
     */
    prefix: Prefix(),
    /**
     * Application environment
     */
    environment: normalizeMode(),
    /**
     * Application port
     */
    port: readAppPort(),
    /**
     * Application host
     */
    host: readEnvString('HOST', Env.HOST),
    /**
     * Is development environment
     */
    isDevelopment() {
        return this.environment === 'development';
    },
    /**
     * Is production environment
     */
    isProduction() {
        return this.environment === 'production';
    },
    /**
     * Is testing environment
     */
    isTesting() {
        return this.environment === 'testing';
    },
    /**
     * Application debug mode
     */
    debug: readEnvBool('DEBUG', Env.DEBUG),
    /**
     *  Indicates if the application is running inside a Docker worker container
     */
    dockerWorker: readEnvBool('DOCKER_WORKER', Env.DOCKER_WORKER),
    /**
     * Indicates if the application is running as a Cloudflare Worker
     */
    cloudflareWorker: readEnvBool('CLOUDFLARE_WORKER', Env.CLOUDFLARE_WORKER),
    /**
     * Indicates if the application is running as a generic Worker (e.g. Cloudflare, AWS Lambda)
     */
    worker: readEnvBool('WORKER_ENABLED', Env.WORKER_ENABLED),
    /**
     * Application timezone
     */
    timezone: readEnvString('APP_TIMEZONE', Env.APP_TIMEZONE),
    /**
     * Request timeout (milliseconds)
     */
    requestTimeout: readEnvInt('REQUEST_TIMEOUT', Env.REQUEST_TIMEOUT),
    /**
     * Max request body size
     */
    maxBodySize: readEnvInt('MAX_BODY_SIZE', Env.MAX_BODY_SIZE),
    getSafeEnv,
    detectRuntime,
};
export const appConfig = Object.freeze(appConfigObj);
export { getSafeEnv };
