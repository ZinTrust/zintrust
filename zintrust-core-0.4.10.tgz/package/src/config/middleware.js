import { Env } from './env.js';
import { bodyParsingMiddleware } from '../http/middleware/BodyParsingMiddleware.js';
import { fileUploadMiddleware } from '../http/middleware/FileUploadMiddleware.js';
import { AuthMiddleware } from '../middleware/AuthMiddleware.js';
import { BulletproofAuthMiddleware } from '../middleware/BulletproofAuthMiddleware.js';
import { CsrfMiddleware } from '../middleware/CsrfMiddleware.js';
import { ErrorHandlerMiddleware } from '../middleware/ErrorHandlerMiddleware.js';
import { JwtAuthMiddleware } from '../middleware/JwtAuthMiddleware.js';
import { LoggingMiddleware } from '../middleware/LoggingMiddleware.js';
import { RateLimiter } from '../middleware/RateLimiter.js';
import { SanitizeBodyMiddleware } from '../middleware/SanitizeBodyMiddleware.js';
import { SecurityMiddleware } from '../middleware/SecurityMiddleware.js';
import { ValidationMiddleware } from '../middleware/ValidationMiddleware.js';
import { StartupConfigFile, StartupConfigFileRegistry } from '../runtime/StartupConfigFileRegistry.js';
import { Sanitizer } from '../security/Sanitizer.js';
import { Schema } from '../validation/Validator.js';
export const MiddlewareBody = {
    email: 'email',
    password: 'password',
    name: 'name',
    count: 'count',
};
export const MiddlewareKeys = Object.freeze({
    log: true,
    error: true,
    security: true,
    rateLimit: true,
    sanitizeBody: true,
    fillRateLimit: true,
    authRateLimit: true,
    userMutationRateLimit: true,
    csrf: true,
    auth: true,
    jwt: true,
    bulletproof: true,
    validateLogin: true,
    validateRegister: true,
    validateUserStore: true,
    validateUserUpdate: true,
    validateUserFill: true,
});
// Ensure `ValidationMiddleware` is strongly typed here to avoid `error`-typed values
// triggering `@typescript-eslint/no-unsafe-*` rules.
const Validation = ValidationMiddleware;
const resolveFillRateLimit = (loadMiddlewareConfig) => {
    return {
        windowMs: loadMiddlewareConfig.fillRateLimit?.windowMs ?? 60_000,
        max: loadMiddlewareConfig.fillRateLimit?.max ?? 5,
        message: loadMiddlewareConfig.fillRateLimit?.message ??
            'Too many requests, please try again after 1 minute.',
    };
};
const resolveAuthRateLimit = (loadMiddlewareConfig) => {
    return {
        windowMs: loadMiddlewareConfig.authRateLimit?.windowMs ?? 60_000,
        max: loadMiddlewareConfig.authRateLimit?.max ?? 10,
        message: loadMiddlewareConfig.authRateLimit?.message ??
            'Too many login attempts, please try again after 1 minute.',
    };
};
const resolveUserMutationRateLimit = (loadMiddlewareConfig) => {
    return {
        windowMs: loadMiddlewareConfig.userMutationRateLimit?.windowMs ?? 60_000,
        max: loadMiddlewareConfig.userMutationRateLimit?.max ?? 20,
        message: loadMiddlewareConfig.userMutationRateLimit?.message ??
            'Too many user requests, please try again after 1 minute.',
    };
};
function createRateLimitMiddlewares(loadMiddlewareConfig) {
    const fillRateLimit = RateLimiter.create(resolveFillRateLimit(loadMiddlewareConfig));
    const authRateLimit = RateLimiter.create(resolveAuthRateLimit(loadMiddlewareConfig));
    const userMutationRateLimit = RateLimiter.create(resolveUserMutationRateLimit(loadMiddlewareConfig));
    return Object.freeze({
        rateLimit: RateLimiter.create(),
        fillRateLimit,
        authRateLimit,
        userMutationRateLimit,
    });
}
function createAuthValidationMiddlewares() {
    return {
        validateLogin: Validation.createBodyWithSanitization(Schema.typed()
            .required(MiddlewareBody.email)
            .email(MiddlewareBody.email)
            .required(MiddlewareBody.password)
            .string(MiddlewareBody.password), {
            email: (v) => Sanitizer.email(v).trim().toLowerCase(),
            password: (v) => Sanitizer.safePasswordChars(v),
        }),
        validateRegister: Validation.createBodyWithSanitization(Schema.typed()
            .required(MiddlewareBody.name)
            .string(MiddlewareBody.name)
            .minLength(MiddlewareBody.name, 1)
            .required(MiddlewareBody.email)
            .email(MiddlewareBody.email)
            .required(MiddlewareBody.password)
            .string(MiddlewareBody.password)
            .minLength(MiddlewareBody.password, 8), {
            name: (v) => Sanitizer.nameText(v).trim(),
            email: (v) => Sanitizer.email(v).trim().toLowerCase(),
            password: (v) => Sanitizer.safePasswordChars(v),
        }),
    };
}
function createUserValidationMiddlewares() {
    return {
        validateUserStore: Validation.createBodyWithSanitization(Schema.typed()
            .required(MiddlewareBody.name)
            .string(MiddlewareBody.name)
            .minLength(MiddlewareBody.name, 1)
            .required(MiddlewareBody.email)
            .email(MiddlewareBody.email)
            .required(MiddlewareBody.password)
            .string(MiddlewareBody.password)
            .minLength(MiddlewareBody.password, 8), {
            name: (v) => Sanitizer.nameText(v).trim(),
            email: (v) => Sanitizer.email(v).trim().toLowerCase(),
            password: (v) => Sanitizer.safePasswordChars(v),
        }),
        validateUserUpdate: Validation.createBodyWithSanitization(Schema.typed()
            .custom(MiddlewareBody.name, (v) => v === undefined || typeof v === 'string', MiddlewareBody.name + ' must be a string')
            .minLength(MiddlewareBody.name, 1)
            .custom(MiddlewareBody.email, (v) => v === undefined || typeof v === 'string', MiddlewareBody.email + ' must be a string')
            .custom(MiddlewareBody.password, (v) => v === undefined || typeof v === 'string', MiddlewareBody.password + ' must be a string')
            .minLength(MiddlewareBody.password, 8), {
            name: (v) => Sanitizer.nameText(v).trim(),
            email: (v) => Sanitizer.email(v).trim().toLowerCase(),
            password: (v) => Sanitizer.safePasswordChars(v),
        }),
        validateUserFill: Validation.createBodyWithSanitization(Schema.typed()
            .custom(MiddlewareBody.count, (v) => v === undefined || (typeof v === 'number' && Number.isFinite(v)), MiddlewareBody.count + ' must be a number')
            .min(MiddlewareBody.count, 1)
            .max(MiddlewareBody.count, 100)),
    };
}
function createValidationMiddlewares() {
    return Object.freeze({
        ...createAuthValidationMiddlewares(),
        ...createUserValidationMiddlewares(),
    });
}
function createSharedMiddlewares(loadMiddlewareConfig) {
    const rateLimits = createRateLimitMiddlewares(loadMiddlewareConfig);
    const validations = createValidationMiddlewares();
    return Object.freeze({
        log: LoggingMiddleware.create(),
        error: ErrorHandlerMiddleware.create(),
        security: SecurityMiddleware.create(),
        sanitizeBody: SanitizeBodyMiddleware.create(),
        ...rateLimits,
        csrf: CsrfMiddleware.create({
            skipPaths: loadMiddlewareConfig?.skipPaths ?? [],
        }),
        auth: AuthMiddleware.create(),
        jwt: JwtAuthMiddleware.create(),
        bulletproof: BulletproofAuthMiddleware.create(),
        ...validations,
    });
}
export function createMiddlewareConfig() {
    const loadMiddlewareConfig = StartupConfigFileRegistry.get(StartupConfigFile.Middleware) ?? {};
    const skipPathsFromEnv = Env.get('CSRF_SKIP_PATHS', '')
        .split(',')
        .map((path) => path.trim())
        .filter((path) => path.length > 0);
    const effectiveMiddlewareConfig = {
        ...loadMiddlewareConfig,
        skipPaths: Array.isArray(loadMiddlewareConfig.skipPaths) && loadMiddlewareConfig.skipPaths.length > 0
            ? loadMiddlewareConfig.skipPaths
            : skipPathsFromEnv,
    };
    const shared = createSharedMiddlewares(effectiveMiddlewareConfig);
    const middlewareConfigObj = {
        global: [
            shared.log,
            shared.error,
            shared.security,
            shared.rateLimit,
            fileUploadMiddleware,
            bodyParsingMiddleware,
            shared.csrf,
            shared.sanitizeBody,
        ],
        route: shared,
    };
    return Object.freeze(middlewareConfigObj);
}
let cached = null;
/**
 * Clear the middleware configuration cache
 * This ensures fresh config loading in watch mode
 */
export const clearMiddlewareConfigCache = () => {
    cached = null;
};
// Proxy target must satisfy JS Proxy invariants.
// When we lazily create a frozen config object (with non-configurable properties),
// we mirror its property descriptors onto this target so reflective operations
// like Object.getOwnPropertyDescriptor() do not throw.
const proxyTarget = {};
function ensureMiddlewareConfig() {
    if (cached)
        return cached;
    cached = createMiddlewareConfig();
    try {
        Object.defineProperties(proxyTarget, Object.getOwnPropertyDescriptors(cached));
    }
    catch {
        // best-effort; proxy still functions via `get` trap even if reflection fails
    }
    return cached;
}
export const middlewareConfig = new Proxy(proxyTarget, {
    get(_target, prop) {
        return ensureMiddlewareConfig()[prop];
    },
    ownKeys() {
        ensureMiddlewareConfig();
        return Reflect.ownKeys(proxyTarget);
    },
    getOwnPropertyDescriptor(_target, prop) {
        ensureMiddlewareConfig();
        return Object.getOwnPropertyDescriptor(proxyTarget, prop);
    },
});
export default middlewareConfig;
