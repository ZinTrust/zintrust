/**
 * Startup Configuration
 *
 * Startup-only controls (evaluated during Application.boot()).
 */
import { Env } from './env.js';
export const startupConfig = Object.freeze({
    healthChecksEnabled: Env.getBool('STARTUP_HEALTH_CHECKS', true),
    validateSecrets: Env.getBool('STARTUP_VALIDATE_SECRETS', true),
    requireEnv: Env.getBool('STARTUP_REQUIRE_ENV', false),
    checkDatabase: Env.getBool('STARTUP_CHECK_DB', false),
    checkCache: Env.getBool('STARTUP_CHECK_CACHE', false),
    timeoutMs: Env.getInt('STARTUP_HEALTH_TIMEOUT_MS', 2500),
    continueOnFailure: Env.getBool('STARTUP_CONTINUE_ON_FAILURE', false),
});
export default startupConfig;
