/**
 * Configuration Exports
 * Central export point for all configuration
 */
import { appConfig } from './app.js';
import broadcastConfig from './broadcast.js';
import { cacheConfig } from './cache.js';
import { databaseConfig } from './database.js';
import { microservicesConfig } from './microservices.js';
import { middlewareConfig } from './middleware.js';
import notificationConfig from './notification.js';
import { queueConfig } from './queue.js';
import { securityConfig } from './security.js';
import { storageConfig } from './storage.js';
export { appConfig } from './app.js';
export { default as broadcastConfig } from './broadcast.js';
export { cacheConfig } from './cache.js';
export { databaseConfig } from './database.js';
export { microservicesConfig } from './microservices.js';
export { middlewareConfig } from './middleware.js';
export { notificationConfig } from './notification.js';
export { queueConfig } from './queue.js';
export { securityConfig } from './security.js';
export { storageConfig } from './storage.js';
export { createRedisConnection } from './workers.js';
/**
 * Combined configuration object
 * Sealed namespace for immutability
 */
export const config = Object.freeze({
    get middleware() {
        return middlewareConfig;
    },
    get app() {
        return appConfig;
    },
    get broadcast() {
        return broadcastConfig;
    },
    get database() {
        return databaseConfig;
    },
    get storage() {
        return storageConfig;
    },
    get notification() {
        return notificationConfig;
    },
    get security() {
        return securityConfig;
    },
    get microservices() {
        return microservicesConfig;
    },
    get cache() {
        return cacheConfig;
    },
    get queue() {
        return queueConfig;
    },
});
