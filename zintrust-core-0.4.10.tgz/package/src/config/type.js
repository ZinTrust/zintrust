export const PackageTyps = {
    Broadcast: 'Broadcast',
    Cache: 'Cache',
    Database: 'Database',
    Mail: 'Mail',
    Middleware: 'Middleware',
    Notification: 'Notification',
    Queue: 'Queue',
    Storage: 'Storage',
};
