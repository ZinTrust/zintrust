import { ErrorFactory } from './exceptions/ZintrustError.js';
import { ZintrustLang } from './lang/lang.js';
import { normalizeActiveServiceRuntime, } from './microservices/ServiceManifest.js';
import { ProjectRuntime } from './runtime/ProjectRuntime.js';
import { isNodeRuntime } from './runtime/detectRuntime.js';
const fileUrlToPathLike = (value) => {
    if (!value.startsWith(ZintrustLang.FILE_PROTOCOL))
        return value;
    // Basic file URL decoding (sufficient for macOS/Linux paths).
    try {
        return decodeURIComponent(value.slice(ZintrustLang.FILE_PROTOCOL.length));
    }
    catch {
        return value.slice(ZintrustLang.FILE_PROTOCOL.length);
    }
};
export const isNodeMain = (importMetaUrl) => {
    if (!isNodeRuntime())
        return false;
    const argv1 = process.argv;
    const scriptPath = Array.isArray(argv1) ? String(argv1[1] ?? '') : '';
    if (scriptPath === '')
        return false;
    const here = fileUrlToPathLike(importMetaUrl);
    if (scriptPath === here)
        return true;
    // Best-effort: handle relative argv paths and runner wrappers.
    return scriptPath.endsWith(here);
};
export const configureStandaloneService = (activeService) => {
    const normalized = normalizeActiveServiceRuntime(activeService);
    if (normalized === undefined) {
        throw ErrorFactory.createValidationError('Standalone service runtime requires at least domain and name.');
    }
    return ProjectRuntime.set({ activeService: normalized }).activeService ?? normalized;
};
export const bootStandaloneService = async (importMetaUrl, activeService) => {
    const configuredService = configureStandaloneService(activeService);
    if (isNodeMain(importMetaUrl)) {
        await start();
    }
    return configuredService;
};
/**
 * Start the Node server (dev/prod) by delegating to the framework bootstrap.
 *
 * This uses a non-literal dynamic import so Worker bundlers don't pull Node-only modules.
 */
export const start = async () => {
    if (!isNodeRuntime())
        return;
    // Compiled output places bootstrap at `dist/src/boot/bootstrap.js`.
    // This file compiles to `dist/src/start.js`, so relative import is stable.
    // In unit tests, importing bootstrap has heavy side effects (starts server + exits).
    await import('./boot/bootstrap.js');
};
/**
 * Cloudflare Workers entry (module worker style).
 */
export { default } from './functions/cloudflare.js';
export { default as cloudflareWorker } from './functions/cloudflare.js';
/**
 * Deno fetch handler.
 */
export { default as deno } from './functions/deno.js';
/**
 * AWS Lambda handler.
 */
export { handler } from './functions/lambda.js';
