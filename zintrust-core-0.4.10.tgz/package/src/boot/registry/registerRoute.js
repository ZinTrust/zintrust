import { appConfig } from '../../config/index.js';
import Logger from '../../config/logger.js';
import { isObject } from '../../helper/index.js';
import * as path from '../../node-singletons/path.js';
import { pathToFileURL } from '../../node-singletons/url.js';
import { detectRuntime } from '../../runtime/detectRuntime.js';
import { ProjectRuntime } from '../../runtime/ProjectRuntime.js';
const isCloudflare = detectRuntime().isCloudflare;
export const isCompiledJsModule = () => {
    // When running from dist, this module is compiled to .js and Node ESM resolution
    // requires explicit file extensions for relative imports.
    const metaUrl = typeof import.meta?.url === 'string' ? import.meta.url : '';
    return metaUrl.endsWith('.js');
};
export const tryImportOptional = async (modulePath) => {
    try {
        return (await import(modulePath));
    }
    catch {
        return undefined;
    }
};
export const tryImportOptionalR = async (modulePath) => {
    try {
        return (await import(modulePath));
    }
    catch (error) {
        Logger.error(`Error importing module ${modulePath}:`, error);
        return undefined;
    }
};
const tryImportRoutesFromAppBase = async (resolvedBasePath) => {
    if (resolvedBasePath === '')
        return undefined;
    const routeCandidates = appConfig.isDevelopment()
        ? [
            path.join(resolvedBasePath, 'routes', 'api.ts'),
            path.join(resolvedBasePath, 'routes', 'api.js'),
        ]
        : [
            path.join(resolvedBasePath, 'routes', 'api.js'),
            path.join(resolvedBasePath, 'dist', 'routes', 'api.js'),
            path.join(resolvedBasePath, 'routes', 'api.ts'),
            path.join(resolvedBasePath, 'dist', 'routes', 'api.ts'),
        ];
    for (const routePath of routeCandidates) {
        try {
            const url = pathToFileURL(routePath).href;
            // eslint-disable-next-line no-await-in-loop
            return (await import(url));
        }
        catch {
            // try next candidate
        }
    }
    return undefined;
};
const registerAppRoutes = async (resolvedBasePath, router) => {
    const mod = await tryImportRoutesFromAppBase(resolvedBasePath);
    if (mod && typeof mod.registerRoutes === 'function') {
        mod.registerRoutes(router);
    }
};
const registerManifestRoutes = async (router) => {
    const serviceManifest = ProjectRuntime.getServiceManifest();
    if (serviceManifest.length === 0)
        return;
    for (const entry of serviceManifest) {
        if (entry.monolithEnabled === false || typeof entry.loadRoutes !== 'function') {
            continue;
        }
        try {
            // eslint-disable-next-line no-await-in-loop
            const mod = await entry.loadRoutes();
            if (isObject(mod) && typeof mod.registerRoutes === 'function') {
                mod.registerRoutes(router);
            }
        }
        catch (error) {
            Logger.warn(`Failed to register manifest routes for ${entry.id}`, error);
        }
    }
};
const registerFrameworkRoutes = async (resolvedBasePath, router) => {
    const frameworkRoutes = await tryImportRoutesFromAppBase(resolvedBasePath);
    if (frameworkRoutes && typeof frameworkRoutes.registerRoutes === 'function') {
        frameworkRoutes.registerRoutes(router);
    }
};
const registerGlobalRoutes = (router) => {
    const globalRoutes = globalThis.__zintrustRoutes;
    if (globalRoutes && typeof globalRoutes.registerRoutes === 'function') {
        globalRoutes.registerRoutes(router);
    }
    else {
        Logger.warn('No app routes found and framework routes are unavailable. Ensure routes/api.ts exists in the project.');
    }
};
export const registerMasterRoutes = async (resolvedBasePath, router) => {
    try {
        if (isCloudflare) {
            registerGlobalRoutes(router);
        }
        if (!isCloudflare) {
            await registerAppRoutes(resolvedBasePath, router);
        }
        await registerManifestRoutes(router);
        if (router.routes.length === 0) {
            await registerFrameworkRoutes(resolvedBasePath, router);
        }
        // Always register core framework routes (health, metrics, doc) after app routes
        // This ensures app can override but core routes always exist
        const { registerCoreRoutes } = await import('../../routes/CoreRoutes.js');
        registerCoreRoutes(router);
    }
    catch (error) {
        Logger.error('Failed to register routes:', error);
    }
};
