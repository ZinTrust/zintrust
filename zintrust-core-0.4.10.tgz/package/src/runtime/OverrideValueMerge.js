import { isObject } from '../helper/index.js';
export const mergeOverrideValues = (base, override) => {
    if (!isObject(base) || !isObject(override)) {
        return override;
    }
    const merged = { ...base };
    for (const [key, value] of Object.entries(override)) {
        const current = merged[key];
        merged[key] =
            isObject(current) && isObject(value) ? mergeOverrideValues(current, value) : value;
    }
    return merged;
};
export default mergeOverrideValues;
