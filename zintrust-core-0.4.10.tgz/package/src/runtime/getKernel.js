import { Application } from '../boot/Application.js';
import { Kernel } from '../http/Kernel.js';
let kernelPromise = null;
export async function getKernel() {
    if (kernelPromise !== null) {
        return kernelPromise;
    }
    const initialize = async () => {
        const app = Application.create();
        await app.boot();
        return Kernel.create(app.getRouter(), app.getContainer());
    };
    kernelPromise = initialize().catch((error) => {
        // Allow retry on subsequent calls if initialization fails.
        kernelPromise = null;
        throw error;
    });
    return kernelPromise;
}
/**
 * Test-only helper.
 *
 * Allows unit tests to reset the singleton between cases without leaking state.
 */
export function __resetKernelForTests() {
    kernelPromise = null;
}
