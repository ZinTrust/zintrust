const normalizeName = (name) => String(name ?? '').trim();
export const InMemoryScheduleStateStore = Object.freeze({
    create() {
        const states = new Map();
        return Object.freeze({
            async get(name) {
                const key = normalizeName(name);
                if (key.length === 0)
                    return null;
                return states.get(key) ?? null;
            },
            async set(name, patch) {
                const key = normalizeName(name);
                if (key.length === 0)
                    return;
                const current = states.get(key) ?? {};
                states.set(key, { ...current, ...patch });
            },
            async list() {
                return Array.from(states.entries()).map(([name, state]) => ({ name, state }));
            },
        });
    },
});
export default {
    InMemoryScheduleStateStore,
};
