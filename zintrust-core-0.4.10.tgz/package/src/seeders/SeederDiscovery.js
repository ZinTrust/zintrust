import fs from '../node-singletons/fs.js';
import * as path from '../node-singletons/path.js';
const isSeederFile = (file) => {
    if (file.endsWith('.d.ts'))
        return false;
    return file.endsWith('.ts') || file.endsWith('.js');
};
export const SeederDiscovery = Object.freeze({
    resolveDir(projectRoot, dir) {
        return path.resolve(projectRoot, dir);
    },
    listSeederFiles(dir) {
        if (!fs.existsSync(dir))
            return [];
        const files = fs.readdirSync(dir);
        return files
            .filter(isSeederFile)
            .sort((a, b) => a.localeCompare(b))
            .map((f) => path.join(dir, f));
    },
});
