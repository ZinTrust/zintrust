import { Env } from '../config/env.js';
import { Logger } from '../config/logger.js';
import ErrorRouting from '../routes/error.js';
import { ErrorResponse } from '../http/ErrorResponse.js';
import { RequestContext } from '../http/RequestContext.js';
const isWritableEnded = (res) => {
    if (typeof res.getRaw !== 'function')
        return false;
    const raw = res.getRaw();
    if (typeof raw !== 'object' || raw === null)
        return false;
    if (!('writableEnded' in raw))
        return false;
    return Boolean(raw.writableEnded);
};
export const ErrorHandlerMiddleware = Object.freeze({
    create() {
        return async (req, res, next) => {
            try {
                await next();
            }
            catch (error) {
                Logger.error('Unhandled request error:', error);
                const requestId = RequestContext.get(req)?.requestId ?? req.context['requestId'];
                const includeStack = Env.NODE_ENV !== 'production';
                if (!isWritableEnded(res)) {
                    const errorMode = Env.get('ERROR_MODE', 'html');
                    res.setStatus(500);
                    if (errorMode === 'html') {
                        // Use HTML error page instead of JSON
                        const handleInternalServerErrorWithWrappers = ErrorRouting.handleInternalServerErrorWithWrappers;
                        await handleInternalServerErrorWithWrappers(req, res, error, requestId);
                    }
                    else {
                        res.json(ErrorResponse.internalServerError('Internal server error', requestId, includeStack ? error?.stack : undefined));
                    }
                }
            }
        };
    },
});
export default ErrorHandlerMiddleware;
