import { SessionManager } from '../session/SessionManager.js';
export const SessionMiddleware = Object.freeze({
    create(options = {}) {
        const manager = SessionManager.create(options);
        return async (req, res, next) => {
            const sessionId = await manager.ensureSessionId(req, res);
            // Keep both request state + context aligned.
            req.sessionId = sessionId;
            req.context['sessionId'] = sessionId;
            res.locals['sessionId'] = sessionId;
            await next();
        };
    },
});
export default SessionMiddleware;
