export const AuthMiddleware = Object.freeze({
    create(options = {}) {
        const headerName = (options.headerName ?? 'authorization').toLowerCase();
        const message = options.message ?? 'Unauthorized';
        return async (req, res, next) => {
            const header = req.getHeader(headerName);
            const value = Array.isArray(header) ? header[0] : header;
            if (typeof value !== 'string' || value.trim() === '') {
                res.setStatus(401).json({ error: message });
                return;
            }
            await next();
        };
    },
});
export default AuthMiddleware;
