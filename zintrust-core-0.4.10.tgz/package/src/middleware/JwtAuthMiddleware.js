import { Logger } from '../config/logger.js';
import { securityConfig } from '../config/security.js';
import { RequestContext } from '../http/RequestContext.js';
import { JwtManager } from '../security/JwtManager.js';
import { JwtSessions } from '../security/JwtSessions.js';
const getHeaderValue = (value) => {
    if (Array.isArray(value))
        return typeof value[0] === 'string' ? value[0] : '';
    return typeof value === 'string' ? value : '';
};
const getBearerToken = (authorizationHeader) => {
    const trimmed = authorizationHeader.trim();
    if (trimmed === '')
        return null;
    const [scheme, ...rest] = trimmed.split(/\s+/);
    if (typeof scheme !== 'string' || scheme.toLowerCase() !== 'bearer')
        return null;
    const token = rest.join(' ').trim();
    if (token === '')
        return null;
    return token;
};
const getOptionalStringOrNumberClaim = (payload, key) => {
    const value = payload[key];
    if (typeof value === 'string')
        return value;
    if (typeof value === 'number')
        return String(value);
    return undefined;
};
export const JwtAuthMiddleware = Object.freeze({
    create(options = {}) {
        const algorithm = options.algorithm ?? securityConfig.jwt.algorithm;
        const secret = options.secret ?? securityConfig.jwt.secret;
        const jwt = JwtManager.create();
        if (algorithm === 'HS256' || algorithm === 'HS512') {
            jwt.setHmacSecret(secret);
        }
        return async (req, res, next) => {
            // If a stronger auth strategy already authenticated this request, do not re-verify.
            if (req.context?.['authStrategy'] === 'bulletproof' && req.user !== undefined) {
                await next();
                return;
            }
            const authorizationHeader = getHeaderValue(req.getHeader('authorization'));
            if (authorizationHeader === '') {
                res.setStatus(401).json({ error: 'Missing authorization header' });
                return;
            }
            const token = getBearerToken(authorizationHeader);
            if (token === null) {
                res.setStatus(401).json({ error: 'Invalid authorization header format' });
                return;
            }
            try {
                const payload = jwt.verify(token, algorithm);
                // Session allowlist: token must exist in the session store to be accepted.
                if (!(await JwtSessions.isActive(token))) {
                    res.setStatus(401).json({ error: 'Invalid or expired token' });
                    return;
                }
                req.user = payload;
                // Standardize request-scoped context fields.
                if (typeof payload.sub === 'string' && payload.sub.trim() !== '') {
                    RequestContext.setUserId(req, payload.sub);
                }
                // Optional: if a tenant claim exists, attach it. (Apps may use a different claim name.)
                const tenantId = getOptionalStringOrNumberClaim(payload, 'tenantId') ??
                    getOptionalStringOrNumberClaim(payload, 'tenant_id');
                if (tenantId !== undefined && tenantId.trim() !== '') {
                    RequestContext.setTenantId(req, tenantId);
                }
                await next();
            }
            catch (error) {
                Logger.debug('JWT verification failed', {
                    algorithm,
                    error: error instanceof Error ? error.message : String(error),
                });
                res.setStatus(401).json({ error: 'Invalid or expired token' });
            }
        };
    },
});
export default JwtAuthMiddleware;
