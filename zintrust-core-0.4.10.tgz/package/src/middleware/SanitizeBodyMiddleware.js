/**
 * Sanitize Body Middleware
 * Applies recursive XSS sanitization (tag stripping + entity escaping) to JSON request bodies.
 *
 * This is a defense-in-depth layer that normalizes untrusted input early.
 */
import { Xss } from '../security/Xss.js';
export const SanitizeBodyMiddleware = Object.freeze({
    create() {
        return async (req, _res, next) => {
            const method = req.getMethod();
            if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS' || method === 'DELETE') {
                await next();
                return;
            }
            if (req.isJson() === false) {
                await next();
                return;
            }
            const rawBody = req.getBody();
            if (rawBody === undefined || rawBody === null) {
                await next();
                return;
            }
            const sanitized = Xss.sanitize(rawBody);
            req.setBody(sanitized);
            await next();
        };
    },
});
export default SanitizeBodyMiddleware;
